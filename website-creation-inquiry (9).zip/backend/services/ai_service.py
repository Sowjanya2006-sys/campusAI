"""AI service abstraction.

    AIService (abstract)
      ├── DemoAIService    -> answers from a local sample knowledge base
      └── NVIDIAAIService  -> RAG retrieval + NVIDIA inference

Selected at runtime by the AI_MODE environment variable.
"""
from __future__ import annotations

import os
from abc import ABC, abstractmethod
from typing import Optional

from rag.retriever import retrieve
from ai.nvidia_client import NvidiaClient


class AIService(ABC):
    mode: str

    @abstractmethod
    def ask(self, question: str, document_id: Optional[str] = None) -> dict:
        ...


class DemoAIService(AIService):
    """Offline demo — never calls NVIDIA. Grounds answers in sample data."""

    mode = "demo"

    def ask(self, question: str, document_id: Optional[str] = None) -> dict:
        hits = retrieve(question, top_k=3)
        if not hits:
            answer = ("I couldn't find that in the Demo Knowledge Base. "
                      "Try asking about a subject, placements, events or the library.")
            return {"answer": answer, "sources": []}
        answer = hits[0]["content"]
        return {
            "answer": answer,
            "sources": [{"title": h["title"], "snippet": h["content"][:120]} for h in hits],
        }


class NVIDIAAIService(AIService):
    """Production — RAG context + NVIDIA inference."""

    mode = "nvidia"

    def __init__(self) -> None:
        self.client = NvidiaClient(
            api_key=os.environ["NVIDIA_API_KEY"],
            base_url=os.environ.get("NVIDIA_BASE_URL", "https://integrate.api.nvidia.com/v1"),
            model=os.environ.get("NVIDIA_MODEL", "meta/llama-3.1-8b-instruct"),
        )

    def ask(self, question: str, document_id: Optional[str] = None) -> dict:
        # 1) Retrieve relevant chunks (RAG)
        hits = retrieve(question, top_k=4, document_id=document_id)
        context = "\n\n".join(h["content"] for h in hits)
        # 2) Build grounded prompt
        prompt = (
            "You are CampusAI, a helpful college assistant. Answer ONLY using the "
            f"context below.\n\nContext:\n{context}\n\nQuestion: {question}\nAnswer:"
        )
        # 3) Call NVIDIA inference
        answer = self.client.generate(prompt)
        return {
            "answer": answer,
            "sources": [{"title": h["title"], "snippet": h["content"][:120]} for h in hits],
        }


def get_ai_service() -> AIService:
    mode = os.environ.get("AI_MODE", "demo").lower()
    return NVIDIAAIService() if mode == "nvidia" else DemoAIService()
