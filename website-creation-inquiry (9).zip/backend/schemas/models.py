"""Pydantic request/response schemas."""
from typing import List, Optional

from pydantic import BaseModel


class AskRequest(BaseModel):
    question: str
    document_id: Optional[str] = None


class Source(BaseModel):
    title: str
    snippet: str


class AskResponse(BaseModel):
    answer: str
    sources: List[Source] = []
