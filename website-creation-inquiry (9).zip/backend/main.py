"""CampusAI FastAPI entry point (reference architecture).

The frontend demo works without this server. In production, set
AI_MODE=nvidia and run this API so the NVIDIAAIService can perform
RAG retrieval and call NVIDIA inference.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.routes import router

app = FastAPI(
    title="CampusAI",
    description="AI-powered college assistant — Let Knowledge Flow.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # restrict in production
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api")


@app.get("/")
def root():
    return {"app": "CampusAI", "tagline": "Let Knowledge Flow.", "status": "online"}
