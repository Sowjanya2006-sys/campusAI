# CampusAI — Backend (FastAPI)

> Reference backend architecture for **NVIDIA CampusAI**.
> The live demo runs entirely in the frontend (Demo Mode). This backend shows how
> the project connects to a real RAG + NVIDIA inference pipeline in production.

## Structure

```
backend/
├── main.py                 # FastAPI app + routes
├── requirements.txt
├── .env.example
├── api/
│   └── routes.py           # /api/ask, /api/documents, /api/health
├── schemas/
│   └── models.py           # Pydantic request/response models
├── services/
│   └── ai_service.py       # AIService abstraction (Demo / NVIDIA)
├── rag/
│   └── retriever.py        # Embeddings + vector search (RAG)
├── ai/
│   └── nvidia_client.py    # NVIDIA inference client wrapper
├── models/
│   └── db_models.py        # SQLAlchemy models (PostgreSQL)
└── database/
    └── session.py          # DB session / engine
```

## Run (production architecture)

```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # set AI_MODE + NVIDIA_API_KEY
uvicorn main:app --reload
```

## AI Mode switching

```
AI_MODE=demo     # local sample knowledge base (default)
AI_MODE=nvidia   # RAG retrieval + NVIDIA inference
```

API keys are read from environment variables **on the server only** and are never
sent to the browser.

## Pipeline

```
Student → FastAPI (/api/ask) → RAG retriever (vector DB)
        → grounded prompt → NVIDIA inference → answer + sources → Student
```
