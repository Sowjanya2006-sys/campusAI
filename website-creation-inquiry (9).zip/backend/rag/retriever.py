"""RAG retriever (reference).

Demo Mode uses a simple keyword match over a sample knowledge base.
Production replaces this with embeddings + a vector database (e.g. pgvector,
FAISS, or Milvus) built from real college PDFs/DOCX/TXT documents.
"""
from __future__ import annotations

from typing import List, Optional

# In production, KNOWLEDGE would be chunks embedded into a vector store.
KNOWLEDGE = [
    {
        "title": "Demo AIML Semester Syllabus.pdf",
        "keywords": ["aiml", "program", "subjects", "syllabus", "curriculum"],
        "content": ("The demo AIML program includes Python Programming, Data Structures, "
                    "DBMS, Operating Systems, Computer Networks and Machine Learning."),
    },
    {
        "title": "Demo Placement Preparation Guide.pdf",
        "keywords": ["placement", "interview", "prepare", "aptitude", "job"],
        "content": ("For placements: revise DSA, DBMS, OS, CN; solve coding problems daily; "
                    "build strong projects; prepare a 1-page resume; do mock interviews."),
    },
]


def _score(question: str, entry: dict) -> int:
    q = question.lower()
    return sum(3 for kw in entry["keywords"] if kw in q)


def retrieve(question: str, top_k: int = 3, document_id: Optional[str] = None) -> List[dict]:
    """Return the top_k most relevant knowledge chunks for a question.

    In production: embed the question, run a vector similarity search, and
    optionally filter by ``document_id``.
    """
    ranked = sorted(
        ((_score(question, e), e) for e in KNOWLEDGE),
        key=lambda x: x[0],
        reverse=True,
    )
    return [e for s, e in ranked if s > 0][:top_k]
