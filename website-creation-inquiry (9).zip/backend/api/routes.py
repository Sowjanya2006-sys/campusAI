"""API routes for CampusAI."""
from fastapi import APIRouter

from schemas.models import AskRequest, AskResponse
from services.ai_service import get_ai_service

router = APIRouter()
ai = get_ai_service()


@router.get("/health")
def health():
    return {"status": "online", "ai_mode": ai.mode}


@router.post("/ask", response_model=AskResponse)
def ask(req: AskRequest):
    """Answer a student question via the active AI service (Demo or NVIDIA)."""
    result = ai.ask(req.question, document_id=req.document_id)
    return result
