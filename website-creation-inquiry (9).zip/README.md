# 🌊 NVIDIA CampusAI — *Let Knowledge Flow.*

An AI-powered college assistant with a lively **waterfall knowledge-flow** theme.
Students can ask about academics, placements, study material, documents and campus
events — and watch information flow like a waterfall from **Question → Knowledge →
AI → Answer**.

> **Runs in Demo Mode out of the box.** No API key, backend, or real college data
> required to demonstrate the full UI. The architecture is designed to later
> connect to NVIDIA-powered inference for production responses.

---

## ✨ Features

| Feature | Description |
|--------|-------------|
| 🌊 Waterfall landing | Interactive canvas visualization (mouse-reactive, click ripples) |
| 🤖 AI Assistant | Chat with typing/thinking animation, suggestions, markdown, copy, sources |
| 📚 AI Study Lab | Explain / Summarize / Generate Questions / Quiz for 7 subjects |
| 💼 AI Placement Lab | Interactive MCQs with explanations + progress visualization |
| 📄 Knowledge Library | Demo documents + "Ask AI about this document" + upload area |
| 📅 Events | Animated demo campus events |
| 📊 Dashboard | Student stats, recent questions, knowledge flow |
| 🧠 About | NVIDIA architecture diagram + RAG explanation |

All data is a clearly-labelled **Demo Knowledge Base** for the fictional
*NVIDIA Institute of Technology*.

---

## 🧱 Tech Stack

- **Frontend:** React + Vite + TypeScript + Tailwind CSS + Lucide Icons + Canvas animation
- **Backend (reference):** Python + FastAPI
- **Database (reference):** PostgreSQL
- **AI architecture:** AIService abstraction · RAG retrieval · NVIDIA inference

## 🗂️ Structure

```
campus-ai/
├── src/                     # React frontend (this is what builds & runs)
│   ├── components/          # Navbar, Footer, WaterfallBackground, KnowledgeFlow
│   ├── pages/               # Landing, Assistant, Study, Placements, Documents, Events, Dashboard, About
│   ├── services/aiService.ts# AIService → DemoAIService / NVIDIAAIService
│   ├── data/knowledgeBase.ts# Demo knowledge base (replaceable with real docs)
│   └── hooks/               # useStats, useReveal
├── backend/                 # FastAPI reference architecture (api, services, rag, ai, models, database)
├── docs/                    # Architecture notes
├── .env.example
└── README.md
```

## 🚀 Run the frontend demo

```bash
npm install      # install dependencies (needs Node.js from nodejs.org)
npm run dev      # development server → http://localhost:5173
npm run build    # production build → outputs to /dist
```

## ☁️ Deploy (free, no backend needed)

The demo is 100% frontend — it works on any static host.

**Option A — GitHub + Vercel (recommended)**
```bash
git init
git add .
git commit -m "CampusAI"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/campus-ai.git
git push -u origin main
```
Then go to [vercel.com](https://vercel.com) → **Add New → Project** → import the repo →
keep defaults (Framework: **Vite**, Build: `npm run build`, Output: `dist`) → **Deploy**.

**Option B — Vercel CLI**
```bash
npm install -g vercel
vercel
```

**Option C — Drag & drop**
Run `npm run build`, then drag the `/dist` folder onto
[app.netlify.com/drop](https://app.netlify.com/drop) or Vercel.

> The `backend/` folder is Python reference code — it is NOT required to run or
> deploy the demo. It only matters when switching to `AI_MODE=nvidia`.

## 🔌 Switching to NVIDIA (production)

1. `backend/.env` → `AI_MODE=nvidia` + set `NVIDIA_API_KEY`
2. Run the FastAPI backend (`uvicorn main:app --reload`)
3. Frontend `.env` → `VITE_AI_MODE=nvidia`

The frontend then calls `POST /api/ask`, which performs RAG retrieval and forwards
a grounded prompt to NVIDIA inference. **API keys live only on the server.**

---

## ⚠️ Disclaimer

This is a student **demo project**. It is **not affiliated with, sponsored,
certified, or endorsed by NVIDIA**. All college information shown is fictional
demo content — never treated as real college data.

**CampusAI — Let Knowledge Flow.** · Demo Project • NVIDIA AI Architecture
