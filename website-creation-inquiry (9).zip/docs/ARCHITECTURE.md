# CampusAI — Architecture & Data Flow

## Knowledge flow (the waterfall metaphor)

```
Student Question
      ↓
Knowledge Retrieval   (search the knowledge base)
      ↓
AI Processing         (assemble context — RAG)
      ↓
NVIDIA AI Layer       (inference generates the answer)
      ↓
Answer                (grounded response + cited sources)
      ↓
Student
```

## AI service abstraction

```
AIService (interface)
 ├── DemoAIService    # offline, sample knowledge base (default)
 └── NVIDIAAIService  # RAG + NVIDIA inference (production)
```

Selection is controlled by an environment variable:

```
AI_MODE=demo     # today
AI_MODE=nvidia   # production
```

## RAG (Retrieval-Augmented Generation)

1. Student asks a question.
2. CampusAI searches its knowledge base (keyword match in demo; vector search in prod).
3. Relevant chunks are retrieved.
4. Chunks are injected as context into a grounded prompt.
5. The AI model generates the final response.
6. Sources are returned and displayed for transparency.

## Production system diagram

```
Student
  → CampusAI Web Interface (React/Vite/Tailwind)
  → FastAPI Backend (/api/ask)
  → Knowledge Retrieval / RAG (embeddings + vector DB over real PDFs)
  → NVIDIA AI Inference
  → Response (answer + sources)
  → Student
```

## Replacing demo data with real documents

- `src/data/knowledgeBase.ts` (frontend demo) and `backend/rag/retriever.py`
  (backend demo) hold the sample content.
- In production, ingest real PDFs/DOCX/TXT → chunk → embed → store in a vector
  database (pgvector / FAISS / Milvus). `retrieve()` then runs similarity search.

## Security

- NVIDIA API keys are stored in `backend/.env` and used only server-side.
- The frontend never contains secrets; it calls the backend `/api/ask` endpoint.
