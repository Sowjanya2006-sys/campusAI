/**
 * AI SERVICE ABSTRACTION
 * ----------------------
 * AIService (interface)
 *   ├── DemoAIService   -> runs fully offline using the demo knowledge base
 *   └── NVIDIAAIService -> stub that will call the FastAPI backend / NVIDIA
 *                          inference endpoint in production.
 *
 * The active service is chosen via the AI_MODE environment variable
 * (VITE_AI_MODE for the frontend). Default = "demo".
 *
 * IMPORTANT: While running in Demo Mode, responses are generated locally
 * from sample data and are NOT produced by NVIDIA models.
 */

import {
  subjects,
  collegeInfo,
  aimlProgram,
  demoEvents,
  demoDocuments,
  placementResources,
} from "../data/knowledgeBase";

export type Source = { title: string; snippet: string };
export type AIResult = { answer: string; sources: Source[] };

export type AskContext = {
  documentId?: string;
  /** Raw text of a user-uploaded document (TXT) to answer from directly. */
  documentText?: string;
  documentName?: string;
};

export interface AIService {
  readonly mode: "demo" | "nvidia";
  ask(question: string, context?: AskContext): Promise<AIResult>;
}

/** Pull the most relevant sentences from a block of text for a question. */
function searchText(question: string, text: string, max = 4): string[] {
  const words = question
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length > 2);
  const sentences = text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?])\s+|\n+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 20);
  const ranked = sentences
    .map((s) => {
      const low = s.toLowerCase();
      const score = words.reduce((acc, w) => acc + (low.includes(w) ? 1 : 0), 0);
      return { s, score };
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score);
  return (ranked.length ? ranked : sentences.map((s) => ({ s, score: 0 })))
    .slice(0, max)
    .map((x) => x.s);
}

/* ----------------- Simple RAG-style retriever (demo) ----------------- */

type KBEntry = { keywords: string[]; title: string; content: string };

function buildIndex(): KBEntry[] {
  const entries: KBEntry[] = [];

  // Subjects
  for (const s of subjects) {
    entries.push({
      keywords: [s.id, s.name.toLowerCase(), ...s.topics.map((t) => t.toLowerCase())],
      title: `${s.name} — Demo Study Notes`,
      content: `${s.explanation}\n\n**Key topics:** ${s.topics.join(", ")}.`,
    });
    for (const qa of s.questions) {
      entries.push({
        keywords: [s.name.toLowerCase(), ...qa.q.toLowerCase().split(/\s+/)],
        title: `${s.name} — Q&A`,
        content: `**${qa.q}**\n\n${qa.a}`,
      });
    }
  }

  // AIML program
  entries.push({
    keywords: ["aiml", "program", "subjects", "syllabus", "curriculum", "course"],
    title: "Demo AIML Semester Syllabus.pdf",
    content: `The demo **AIML program** includes: ${aimlProgram.coreSubjects.join(
      ", "
    )}. ${aimlProgram.description}`,
  });

  // College info
  entries.push({
    keywords: ["college", "institute", "overview", "about", "departments", "programs"],
    title: "Demo College Handbook.pdf",
    content: `**${collegeInfo.name}** (demo). ${collegeInfo.overview}\n\n**Departments:** ${collegeInfo.departments.join(
      ", "
    )}.`,
  });
  entries.push({
    keywords: ["library", "books", "resources", "reading"],
    title: "Demo College Handbook.pdf — Library",
    content: `Library (demo): ${collegeInfo.library.hours}. ${collegeInfo.library.resources}. ${collegeInfo.library.services}.`,
  });
  entries.push({
    keywords: ["lab", "labs", "gpu", "facilities", "campus", "computer"],
    title: "Demo College Handbook.pdf — Facilities",
    content: `Facilities (demo): ${collegeInfo.facilities.join("; ")}.\n\n**Labs:** ${collegeInfo.labs.join(
      ", "
    )}.`,
  });
  entries.push({
    keywords: ["club", "clubs", "society", "activities"],
    title: "Demo College Handbook.pdf — Clubs",
    content: `Student clubs (demo): ${collegeInfo.clubs.join(", ")}.`,
  });

  // Placements
  entries.push({
    keywords: ["placement", "placements", "interview", "prepare", "preparation", "job", "career"],
    title: "Demo Placement Preparation Guide.pdf",
    content: `**Placement preparation (demo):**\n\n${placementResources.preparation
      .map((p) => `- ${p}`)
      .join("\n")}\n\n**Technical topics:** ${placementResources.technicalTopics.join(", ")}.`,
  });
  entries.push({
    keywords: ["aptitude", "quant", "reasoning", "logical", "verbal"],
    title: "Demo Placement Preparation Guide.pdf — Aptitude",
    content: `**Aptitude topics (demo):**\n\n${placementResources.aptitudeTopics
      .map((p) => `- ${p}`)
      .join("\n")}`,
  });
  entries.push({
    keywords: ["mock", "company", "companies", "categories"],
    title: "Demo Placement Preparation Guide.pdf — Mock & Companies",
    content: `${placementResources.mockInterview}\n\n**Company categories (demo):** ${placementResources.companyCategories.join(
      ", "
    )}.`,
  });

  // Events
  entries.push({
    keywords: ["event", "events", "workshop", "hackathon", "seminar", "competition", "fest"],
    title: "Demo Campus Events",
    content: `Upcoming **demo events**:\n\n${demoEvents
      .map((e) => `- **${e.title}** (${e.category}) — ${e.date}, ${e.time} @ ${e.venue}`)
      .join("\n")}`,
  });

  // Documents
  entries.push({
    keywords: ["document", "documents", "pdf", "notes", "material", "materials", "handbook"],
    title: "Demo Knowledge Library",
    content: `Available **demo documents**:\n\n${demoDocuments
      .map((d) => `- 📄 ${d.name} (${d.pages} pages) — ${d.summary}`)
      .join("\n")}`,
  });

  return entries;
}

const INDEX = buildIndex();

function score(query: string, entry: KBEntry): number {
  const q = query.toLowerCase();
  const words = q.split(/[^a-z0-9]+/).filter((w) => w.length > 2);
  let s = 0;
  for (const kw of entry.keywords) {
    if (q.includes(kw)) s += 3;
    for (const w of words) {
      if (kw.includes(w) || w.includes(kw)) s += 1;
    }
  }
  return s;
}

function retrieve(query: string, topK = 3): KBEntry[] {
  return INDEX.map((e) => ({ e, s: score(query, e) }))
    .filter((x) => x.s > 0)
    .sort((a, b) => b.s - a.s)
    .slice(0, topK)
    .map((x) => x.e);
}

/* ----------------- Demo AI Service ----------------- */

export class DemoAIService implements AIService {
  readonly mode = "demo" as const;

  async ask(question: string, context?: AskContext): Promise<AIResult> {
    // simulate latency for the "thinking" animation
    await new Promise((r) => setTimeout(r, 250));

    // 1) If the user uploaded a document with text, answer directly from it.
    if (context?.documentText && context.documentText.trim().length > 0) {
      const name = context.documentName || "your uploaded document";
      const matches = searchText(question, context.documentText);
      if (matches.length === 0) {
        return {
          answer: `I read **${name}** but couldn't find anything matching your question. Try rephrasing, or ask me to "summarize this document".`,
          sources: [{ title: name, snippet: "Uploaded document (read locally)" }],
        };
      }
      const wantsSummary = /summar|overview|about|tl;?dr|key points/i.test(question);
      const body = wantsSummary
        ? `Here's a quick summary of **${name}** (demo):\n\n${matches
            .map((m) => `- ${m}`)
            .join("\n")}`
        : `From **${name}**:\n\n${matches.map((m) => `> ${m}`).join("\n\n")}`;
      return {
        answer:
          body +
          `\n\n*Answered directly from your uploaded file, read locally in your browser (Demo Mode).*`,
        sources: [{ title: name, snippet: matches[0].slice(0, 120) + "…" }],
      };
    }

    let docNote = "";
    if (context?.documentId) {
      const doc = demoDocuments.find((d) => d.id === context.documentId);
      if (doc) docNote = `\n\n*Context: answering based on **${doc.name}** (demo document).*`;
    }

    const hits = retrieve(question);

    if (hits.length === 0) {
      return {
        answer:
          "I couldn't find that in the **Demo Knowledge Base**. Try asking about a subject (Python, DBMS, Data Structures, OS, CN, Machine Learning), the AIML program, placements, events, the library or campus facilities." +
          docNote,
        sources: [],
      };
    }

    const primary = hits[0];
    const answer =
      `${primary.content}` +
      (hits.length > 1
        ? `\n\n---\n**Related from the demo knowledge base:**\n${hits
            .slice(1)
            .map((h) => `- ${h.title}`)
            .join("\n")}`
        : "") +
      docNote;

    return {
      answer,
      sources: hits.map((h) => ({
        title: h.title,
        snippet: h.content.replace(/[*#`]/g, "").slice(0, 120) + "…",
      })),
    };
  }
}

/* ----------------- NVIDIA AI Service (production stub) ----------------- */

export class NVIDIAAIService implements AIService {
  readonly mode = "nvidia" as const;

  async ask(question: string, context?: AskContext): Promise<AIResult> {
    // In production this calls the FastAPI backend which performs RAG
    // retrieval and forwards the grounded prompt to an NVIDIA inference
    // endpoint. API keys live ONLY on the server, never in the frontend.
    const res = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question,
        documentId: context?.documentId,
        documentText: context?.documentText,
      }),
    });
    if (!res.ok) throw new Error("NVIDIA inference request failed");
    return (await res.json()) as AIResult;
  }
}

/* ----------------- Factory ----------------- */

const AI_MODE = (import.meta.env.VITE_AI_MODE as string) || "demo";

export const aiService: AIService =
  AI_MODE === "nvidia" ? new NVIDIAAIService() : new DemoAIService();

export const IS_DEMO = aiService.mode === "demo";
