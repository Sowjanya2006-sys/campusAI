import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import ReactMarkdown from "react-markdown";
import {
  Send,
  Sparkles,
  Trash2,
  Copy,
  Check,
  Droplets,
  FileText,
  X,
  User,
} from "lucide-react";
import WaterfallBackground from "../components/WaterfallBackground";
import { aiService, IS_DEMO, type Source } from "../services/aiService";
import { demoDocuments } from "../data/knowledgeBase";
import { useStats } from "../hooks/useStats";
import { useUploads } from "../hooks/useUploads";

type Msg = {
  id: number;
  role: "user" | "ai";
  content: string;
  sources?: Source[];
};

const suggestions = [
  "What subjects are in the AIML program?",
  "Explain Python functions.",
  "What topics should I study for placements?",
  "Summarize the demo syllabus.",
  "What events are available?",
];

const stages = ["Retrieving knowledge...", "Processing with CampusAI...", "Generating response..."];

export default function Assistant() {
  const [params, setParams] = useSearchParams();
  const { track } = useStats();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [stageIdx, setStageIdx] = useState(0);
  const [copied, setCopied] = useState<number | null>(null);
  const [docId, setDocId] = useState<string | undefined>(params.get("doc") || undefined);
  const { getById } = useUploads();
  const [uploadId, setUploadId] = useState<string | undefined>(params.get("upload") || undefined);
  const endRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(1);

  const activeUpload = uploadId ? getById(uploadId) : undefined;
  const demoDoc = demoDocuments.find((d) => d.id === docId);
  const activeDoc = activeUpload
    ? { name: activeUpload.name }
    : demoDoc
    ? { name: demoDoc.name }
    : undefined;

  function clearContext() {
    setDocId(undefined);
    setUploadId(undefined);
  }

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, busy]);

  // auto-send a question passed via ?q=
  useEffect(() => {
    const q = params.get("q");
    if (q) {
      send(q);
      params.delete("q");
      setParams(params, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function send(text: string) {
    const q = text.trim();
    if (!q || busy) return;
    const userMsg: Msg = { id: idRef.current++, role: "user", content: q };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setBusy(true);
    setStageIdx(0);

    // cycle through the pipeline stages for the animation
    const timers: number[] = [];
    timers.push(window.setTimeout(() => setStageIdx(1), 500));
    timers.push(window.setTimeout(() => setStageIdx(2), 1000));

    try {
      const upload = uploadId ? getById(uploadId) : undefined;
      const result = await aiService.ask(q, {
        documentId: docId,
        documentText: upload?.text,
        documentName: upload?.name,
      });
      // ensure the animation is visible a little
      await new Promise((r) => setTimeout(r, 1200));
      setMessages((m) => [
        ...m,
        { id: idRef.current++, role: "ai", content: result.answer, sources: result.sources },
      ]);
      track("question", q);
    } catch {
      setMessages((m) => [
        ...m,
        {
          id: idRef.current++,
          role: "ai",
          content:
            "⚠️ Something went wrong reaching the AI service. In Demo Mode this shouldn't happen — please try again.",
        },
      ]);
    } finally {
      timers.forEach(clearTimeout);
      setBusy(false);
    }
  }

  function copy(id: number, text: string) {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 1500);
  }

  return (
    <div className="relative min-h-screen">
      <WaterfallBackground intensity={busy ? 0.9 : 0.12} />
      <div className="pointer-events-none absolute inset-0 grid-flow opacity-40" />

      <div className="relative mx-auto flex min-h-screen max-w-4xl flex-col px-4 pt-24 pb-6 sm:px-6">
        {/* header */}
        <div className="reveal in-view text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-flow-500/20 bg-flow-500/5 px-3 py-1 text-xs font-medium text-flow-400">
            <span className="h-2 w-2 rounded-full bg-flow-400" /> {IS_DEMO ? "DEMO MODE" : "NVIDIA MODE"}
          </div>
          <h1 className="mt-3 text-3xl font-bold tracking-tight text-white sm:text-4xl">
            Campus<span className="text-flow">AI</span>
          </h1>
          <p className="mt-1.5 text-sm text-slate-400">
            Ask anything from the campus knowledge base.
          </p>
        </div>

        {/* doc context chip */}
        {activeDoc && (
          <div className="mx-auto mt-4 flex items-center gap-2 rounded-full glass px-3 py-1.5 text-xs text-slate-200">
            <FileText className="h-4 w-4 text-flow-400" />
            {activeUpload ? "Your upload: " : "Context: "}
            {activeDoc.name}
            {activeUpload && !activeUpload.text && (
              <span className="text-amber-300">(text not extracted)</span>
            )}
            <button onClick={clearContext} className="ml-1 rounded-full p-0.5 hover:bg-white/10">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        {/* chat area */}
        <div className="mt-5 flex-1 space-y-5 overflow-y-auto rounded-3xl glass p-4 sm:p-6">
          {messages.length === 0 && !busy && (
            <div className="flex h-full min-h-[220px] flex-col items-center justify-center text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-flow-500 to-cyan-400 shadow-lg shadow-flow-500/30 animate-float">
                <Droplets className="h-8 w-8 text-[#04120b]" strokeWidth={2.4} />
              </div>
              <p className="mt-4 max-w-sm text-sm text-slate-400">
                Hi! I'm <span className="font-semibold text-flow-400">Aqua</span> 💧 — start the flow!
                Pick a suggested question below or type your own.
                Responses come from the <span className="text-flow-400">Demo Knowledge Base</span>.
              </p>
              <div className="mt-4 flex gap-2 text-2xl">
                {["🌊", "🤖", "📚", "⚡", "🎓"].map((e, i) => (
                  <span key={e} className="animate-float" style={{ animationDelay: `${i * 0.3}s` }}>
                    {e}
                  </span>
                ))}
              </div>
            </div>
          )}

          {messages.map((m) =>
            m.role === "user" ? (
              <div key={m.id} className="flex justify-end gap-3">
                <div className="max-w-[80%] rounded-2xl rounded-tr-sm bg-gradient-to-br from-flow-500 to-cyan-400 px-4 py-2.5 text-sm font-medium text-[#04120b]">
                  {m.content}
                </div>
                <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10">
                  <User className="h-4 w-4 text-slate-200" />
                </div>
              </div>
            ) : (
              <div key={m.id} className="flex gap-3">
                <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-flow-500 to-cyan-400">
                  <Droplets className="h-4 w-4 text-[#04120b]" strokeWidth={2.4} />
                </div>
                <div className="max-w-[85%]">
                  <div className="rounded-2xl rounded-tl-sm bg-white/[0.04] px-4 py-3 ring-1 ring-white/5">
                    <div className="md-body text-sm text-slate-200">
                      <ReactMarkdown>{m.content}</ReactMarkdown>
                    </div>
                  </div>
                  {m.sources && m.sources.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {m.sources.map((s, i) => (
                        <span
                          key={i}
                          className="inline-flex items-center gap-1 rounded-full bg-flow-500/10 px-2.5 py-1 text-[11px] text-flow-400 ring-1 ring-flow-500/20"
                          title={s.snippet}
                        >
                          <FileText className="h-3 w-3" /> {s.title}
                        </span>
                      ))}
                    </div>
                  )}
                  <button
                    onClick={() => copy(m.id, m.content)}
                    className="mt-1.5 inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-flow-400"
                  >
                    {copied === m.id ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                    {copied === m.id ? "Copied" : "Copy"}
                  </button>
                </div>
              </div>
            )
          )}

          {/* thinking animation */}
          {busy && (
            <div className="flex gap-3">
              <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-flow-500 to-cyan-400">
                <Droplets className="h-4 w-4 animate-pulse text-[#04120b]" strokeWidth={2.4} />
              </div>
              <div className="rounded-2xl rounded-tl-sm bg-white/[0.04] px-4 py-3 ring-1 ring-white/5">
                <div className="flex items-center gap-2">
                  <div className="flex gap-1">
                    <span className="h-2 w-2 animate-bounce rounded-full bg-flow-400 [animation-delay:-0.3s]" />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-flow-400 [animation-delay:-0.15s]" />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-flow-400" />
                  </div>
                  <span className="text-sm text-flow-400">{stages[stageIdx]}</span>
                </div>
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>

        {/* suggestions */}
        {messages.length === 0 && (
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {suggestions.map((s) => (
              <button
                key={s}
                onClick={() => send(s)}
                className="rounded-full glass px-3.5 py-1.5 text-xs text-slate-200 transition-colors hover:border-flow-500/40 hover:text-white"
              >
                {s}
              </button>
            ))}
          </div>
        )}

        {/* input */}
        <div className="mt-4 flex items-center gap-2">
          {messages.length > 0 && (
            <button
              onClick={() => setMessages([])}
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl glass text-slate-400 transition-colors hover:text-red-400"
              title="Clear chat"
            >
              <Trash2 className="h-5 w-5" />
            </button>
          )}
          <div className="flex flex-1 items-center gap-2 rounded-2xl glass px-4 py-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send(input)}
              placeholder="Ask CampusAI anything…"
              className="flex-1 bg-transparent py-1.5 text-sm text-white outline-none placeholder:text-slate-500"
            />
            <button
              onClick={() => send(input)}
              disabled={busy || !input.trim()}
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-flow-500 to-cyan-400 text-[#04120b] transition-transform hover:scale-105 disabled:opacity-40"
            >
              {busy ? <Sparkles className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <p className="mt-2 text-center text-[11px] text-slate-600">
          Demo responses are generated locally from sample data — not from NVIDIA models while in Demo Mode.
        </p>
      </div>
    </div>
  );
}
