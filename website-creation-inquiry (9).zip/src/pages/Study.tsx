import { useState } from "react";
import ReactMarkdown from "react-markdown";
import { BookOpen, FileDigit, ListChecks, HelpCircle, Sparkles, Loader2 } from "lucide-react";
import WaterfallBackground from "../components/WaterfallBackground";
import { subjects } from "../data/knowledgeBase";
import { useStats } from "../hooks/useStats";
import { useReveal } from "../hooks/useReveal";

const difficulties = ["Beginner", "Intermediate", "Advanced"] as const;
type Action = "Explain" | "Summarize" | "Generate Questions" | "Generate Quiz";

const actions: { key: Action; icon: typeof BookOpen; color: string }[] = [
  { key: "Explain", icon: BookOpen, color: "#4ade80" },
  { key: "Summarize", icon: FileDigit, color: "#34d399" },
  { key: "Generate Questions", icon: HelpCircle, color: "#22d3ee" },
  { key: "Generate Quiz", icon: ListChecks, color: "#a78bfa" },
];

export default function Study() {
  useReveal();
  const { track } = useStats();
  const [subjectId, setSubjectId] = useState(subjects[0].id);
  const [topic, setTopic] = useState("");
  const [difficulty, setDifficulty] = useState<(typeof difficulties)[number]>("Beginner");
  const [result, setResult] = useState<string | null>(null);
  const [action, setAction] = useState<Action | null>(null);
  const [loading, setLoading] = useState(false);

  const subject = subjects.find((s) => s.id === subjectId)!;

  function generate(a: Action) {
    setAction(a);
    setLoading(true);
    setResult(null);
    setTimeout(() => {
      setResult(build(a));
      setLoading(false);
      track("study", `${a}: ${subject.name}${topic ? " · " + topic : ""}`);
    }, 900);
  }

  function build(a: Action): string {
    const scope = topic ? `**${topic}** (in ${subject.name})` : `**${subject.name}**`;
    const depth =
      difficulty === "Beginner"
        ? "Keeping it simple for beginners"
        : difficulty === "Intermediate"
        ? "At an intermediate level"
        : "With advanced depth";

    if (a === "Explain") {
      return `### Explaining ${scope}\n_${depth}._\n\n${subject.explanation}\n\n**Core topics you should know:**\n${subject.topics
        .map((t) => `- ${t}`)
        .join("\n")}`;
    }
    if (a === "Summarize") {
      return `### ${subject.name} — Summary\n_${depth}._\n\n${subject.summary}\n\n**In short:** master these → ${subject.topics
        .slice(0, 4)
        .join(", ")}.`;
    }
    if (a === "Generate Questions") {
      const extra = subject.topics
        .slice(0, 4)
        .map((t, i) => `${i + 3}. Explain **${t}** with a short example.`)
        .join("\n");
      return `### Practice Questions — ${subject.name}\n_${difficulty} level (demo)._\n\n${subject.questions
        .map((q, i) => `${i + 1}. ${q.q}`)
        .join("\n")}\n${extra}`;
    }
    // Quiz
    return `### Quick Quiz — ${subject.name}\n_${difficulty} level (demo)._\n\n${subject.questions
      .map(
        (q, i) =>
          `**Q${i + 1}. ${q.q}**\n\n<details>\n\n_Answer:_ ${q.a}\n\n</details>`
      )
      .join("\n\n")}\n\n> 💡 Try the **Placement Lab** for interactive MCQs with scoring.`;
  }

  return (
    <div className="relative min-h-screen">
      <WaterfallBackground intensity={loading ? 0.7 : 0.1} />
      <div className="pointer-events-none absolute inset-0 grid-flow opacity-40" />

      <div className="relative mx-auto max-w-5xl px-6 pt-28 pb-16">
        <div className="reveal text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-flow-500/20 bg-flow-500/5 px-3 py-1 text-xs font-medium text-flow-400">
            <BookOpen className="h-3.5 w-3.5" /> DEMO MODE
          </div>
          <h1 className="mt-3 text-4xl font-bold tracking-tight text-white">
            AI Study <span className="text-flow">Lab</span>
          </h1>
          <p className="mt-2 text-slate-400">Explain, summarize and quiz yourself on any subject.</p>
        </div>

        {/* controls */}
        <div className="reveal mt-10 rounded-3xl glass p-6" data-delay="80">
          <label className="text-xs font-semibold uppercase tracking-widest text-slate-400">Subject</label>
          <div className="mt-2 flex flex-wrap gap-2">
            {subjects.map((s) => (
              <button
                key={s.id}
                onClick={() => setSubjectId(s.id)}
                className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-medium transition-all ${
                  subjectId === s.id
                    ? "bg-flow-500/15 text-flow-400 ring-1 ring-flow-500/40"
                    : "bg-white/[0.03] text-slate-300 ring-1 ring-white/5 hover:text-white"
                }`}
              >
                <span>{s.icon}</span> {s.name}
              </button>
            ))}
          </div>

          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <div>
              <label className="text-xs font-semibold uppercase tracking-widest text-slate-400">
                Topic (optional)
              </label>
              <input
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder={`e.g. ${subject.topics[0]}`}
                className="mt-2 w-full rounded-xl bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none ring-1 ring-white/5 focus:ring-flow-500/40"
              />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-widest text-slate-400">Difficulty</label>
              <div className="mt-2 flex gap-2">
                {difficulties.map((d) => (
                  <button
                    key={d}
                    onClick={() => setDifficulty(d)}
                    className={`flex-1 rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
                      difficulty === d
                        ? "bg-flow-500/15 text-flow-400 ring-1 ring-flow-500/40"
                        : "bg-white/[0.03] text-slate-300 ring-1 ring-white/5 hover:text-white"
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {actions.map((a) => (
              <button
                key={a.key}
                onClick={() => generate(a.key)}
                disabled={loading}
                className="group flex flex-col items-center gap-2 rounded-2xl bg-white/[0.03] p-4 ring-1 ring-white/5 transition-all hover:-translate-y-0.5 hover:ring-flow-500/40 disabled:opacity-50"
              >
                <a.icon className="h-6 w-6" style={{ color: a.color }} />
                <span className="text-xs font-semibold text-white">{a.key}</span>
              </button>
            ))}
          </div>
        </div>

        {/* result */}
        {(loading || result) && (
          <div className="mt-6 overflow-hidden rounded-3xl glass p-6">
            <div className="mb-4 flex items-center gap-2 text-sm font-semibold text-flow-400">
              <Sparkles className="h-4 w-4" /> {action} · {subject.name}
            </div>
            {loading ? (
              <div className="flex items-center gap-3 py-8 text-slate-400">
                <Loader2 className="h-5 w-5 animate-spin text-flow-400" />
                Generating with CampusAI (demo)…
              </div>
            ) : (
              <div className="md-body text-sm text-slate-200">
                <ReactMarkdown>{result!}</ReactMarkdown>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
