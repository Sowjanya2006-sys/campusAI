import { useMemo, useState } from "react";
import { Briefcase, Check, X, ChevronRight, RotateCcw, Trophy, Flame } from "lucide-react";
import WaterfallBackground from "../components/WaterfallBackground";
import Confetti from "../components/Confetti";
import {
  placementCategories,
  placementQuestions,
  placementResources,
} from "../data/knowledgeBase";
import { useStats } from "../hooks/useStats";
import { useReveal } from "../hooks/useReveal";

export default function Placements() {
  useReveal();
  const { track } = useStats();
  const [catId, setCatId] = useState("dsa");
  const [qIndex, setQIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(0);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [confetti, setConfetti] = useState(0);
  const [flash, setFlash] = useState<string | null>(null);

  const questions = useMemo(
    () => placementQuestions[catId] ?? placementQuestions["dsa"],
    [catId]
  );
  const q = questions[qIndex % questions.length];
  const cat = placementCategories.find((c) => c.id === catId)!;

  const correctMsgs = ["Nailed it! 🎯", "Boom! 💥", "Flowing nicely! 🌊", "Genius! 🧠", "On fire! 🔥"];
  const wrongMsgs = ["So close! 💪", "No worries — now you know! 💡", "Learning splash! 💧"];

  function pick(i: number) {
    if (selected !== null) return;
    setSelected(i);
    setAnswered((a) => a + 1);
    if (i === q.answer) {
      setScore((s) => s + 1);
      setConfetti((c) => c + 1);
      setStreak((s) => {
        const ns = s + 1;
        setBestStreak((b) => Math.max(b, ns));
        return ns;
      });
      setFlash(correctMsgs[Math.floor(Math.random() * correctMsgs.length)]);
    } else {
      setStreak(0);
      setFlash(wrongMsgs[Math.floor(Math.random() * wrongMsgs.length)]);
    }
    setTimeout(() => setFlash(null), 1600);
    track("placement", `${cat.name} Q${qIndex + 1}`);
  }

  function next() {
    setSelected(null);
    setQIndex((i) => i + 1);
  }

  function reset(newCat?: string) {
    if (newCat) setCatId(newCat);
    setQIndex(0);
    setSelected(null);
    setScore(0);
    setAnswered(0);
    setStreak(0);
  }

  const accuracy = answered ? Math.round((score / answered) * 100) : 0;

  return (
    <div className="relative min-h-screen">
      <WaterfallBackground intensity={0.1 + Math.min(streak, 5) * 0.12} />
      <Confetti fire={confetti} />
      {flash && (
        <div
          key={flash + confetti}
          className="pointer-events-none fixed left-1/2 top-28 z-[56] -translate-x-1/2 rounded-full glass-strong px-5 py-2 text-lg font-bold text-flow-400 shadow-lg"
          style={{ animation: "fadeUp 0.4s ease" }}
        >
          {flash}
        </div>
      )}
      <div className="pointer-events-none absolute inset-0 grid-flow opacity-40" />

      <div className="relative mx-auto max-w-5xl px-6 pt-28 pb-16">
        <div className="reveal text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-flow-500/20 bg-flow-500/5 px-3 py-1 text-xs font-medium text-flow-400">
            <Briefcase className="h-3.5 w-3.5" /> DEMO MODE
          </div>
          <h1 className="mt-3 text-4xl font-bold tracking-tight text-white">
            AI Placement <span className="text-flow">Lab</span>
          </h1>
          <p className="mt-2 text-slate-400">Practice demo questions with instant explanations.</p>
        </div>

        {/* categories */}
        <div className="reveal mt-8 flex flex-wrap justify-center gap-2" data-delay="60">
          {placementCategories.map((c) => (
            <button
              key={c.id}
              onClick={() => reset(c.id)}
              className={`rounded-xl px-3.5 py-2 text-sm font-medium transition-all ${
                catId === c.id
                  ? "bg-flow-500/15 text-flow-400 ring-1 ring-flow-500/40"
                  : "bg-white/[0.03] text-slate-300 ring-1 ring-white/5 hover:text-white"
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          {/* quiz card */}
          <div className="reveal rounded-3xl glass p-6 lg:col-span-2" data-delay="120">
            <div className="mb-4 flex items-center justify-between text-xs text-slate-400">
              <span className="rounded-full bg-white/5 px-2.5 py-1">{cat.name}</span>
              <span className="rounded-full bg-flow-500/10 px-2.5 py-1 text-flow-400">
                {q.difficulty}
              </span>
            </div>

            <h3 className="text-lg font-semibold text-white">
              Q{qIndex + 1}. {q.question}
            </h3>

            <div className="mt-5 space-y-2.5">
              {q.options.map((opt, i) => {
                const isCorrect = selected !== null && i === q.answer;
                const isWrong = selected === i && i !== q.answer;
                return (
                  <button
                    key={i}
                    onClick={() => pick(i)}
                    disabled={selected !== null}
                    className={`flex w-full items-center justify-between rounded-xl px-4 py-3 text-left text-sm transition-all ${
                      isCorrect
                        ? "bg-flow-500/15 text-flow-400 ring-1 ring-flow-500/50"
                        : isWrong
                        ? "bg-red-500/10 text-red-300 ring-1 ring-red-500/40"
                        : "bg-white/[0.03] text-slate-200 ring-1 ring-white/5 hover:ring-flow-500/30 disabled:opacity-60"
                    }`}
                  >
                    <span>{opt}</span>
                    {isCorrect && <Check className="h-4 w-4" />}
                    {isWrong && <X className="h-4 w-4" />}
                  </button>
                );
              })}
            </div>

            {selected !== null && (
              <div className="mt-4 rounded-xl bg-white/[0.03] p-4 ring-1 ring-white/5">
                <p className="text-xs font-semibold uppercase tracking-widest text-flow-400">
                  Explanation
                </p>
                <p className="mt-1.5 text-sm text-slate-300">{q.explanation}</p>
                <button
                  onClick={next}
                  className="mt-4 flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-flow-500 to-cyan-400 px-4 py-2 text-sm font-semibold text-[#04120b] transition-transform hover:scale-105"
                >
                  Next question <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>

          {/* progress + resources */}
          <div className="space-y-6">
            <div className="reveal rounded-3xl glass p-6 text-center" data-delay="160">
              <Trophy className="mx-auto h-8 w-8 text-flow-400" />
              <p className="mt-2 text-4xl font-bold text-white">
                {score}
                <span className="text-lg text-slate-500">/{answered || 0}</span>
              </p>
              <p className="text-xs text-slate-400">correct answers</p>

              <div className="mt-4 flex items-center justify-center gap-4 text-sm">
                <span className={`inline-flex items-center gap-1 font-semibold ${streak >= 3 ? "text-orange-400" : "text-slate-300"}`}>
                  <Flame className={`h-4 w-4 ${streak >= 3 ? "text-orange-400" : "text-slate-500"}`} />
                  {streak} streak
                </span>
                <span className="text-slate-500">best: {bestStreak}</span>
              </div>

              <div className="mt-4">
                <div className="mb-1 flex justify-between text-xs text-slate-400">
                  <span>Accuracy</span>
                  <span className="text-flow-400">{accuracy}%</span>
                </div>
                <div className="h-2.5 overflow-hidden rounded-full bg-white/10">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-flow-500 to-cyan-400 transition-all duration-500"
                    style={{ width: `${accuracy}%` }}
                  />
                </div>
              </div>
              <button
                onClick={() => reset()}
                className="mt-4 inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-flow-400"
              >
                <RotateCcw className="h-3.5 w-3.5" /> Reset
              </button>
            </div>

            <div className="reveal rounded-3xl glass p-6" data-delay="200">
              <h4 className="text-sm font-semibold text-white">Prep checklist (demo)</h4>
              <ul className="mt-3 space-y-2">
                {placementResources.preparation.slice(0, 4).map((p) => (
                  <li key={p} className="flex gap-2 text-xs text-slate-300">
                    <Check className="h-3.5 w-3.5 shrink-0 text-flow-400" /> {p}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
