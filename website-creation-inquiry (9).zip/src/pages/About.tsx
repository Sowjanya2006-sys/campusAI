import {
  User,
  Globe,
  Server,
  Database,
  Cpu,
  MessageSquareText,
  ArrowDown,
  Info,
  Layers,
  ShieldCheck,
} from "lucide-react";
import WaterfallBackground from "../components/WaterfallBackground";
import { useReveal } from "../hooks/useReveal";

const pipeline = [
  { icon: User, label: "Student", desc: "Asks a question" },
  { icon: Globe, label: "CampusAI Web Interface", desc: "React + Vite + Tailwind frontend" },
  { icon: Server, label: "FastAPI Backend", desc: "Python API layer & orchestration" },
  { icon: Database, label: "Knowledge Retrieval / RAG", desc: "Embeddings + vector search over documents" },
  { icon: Cpu, label: "NVIDIA AI Inference", desc: "LLM generates a grounded answer" },
  { icon: MessageSquareText, label: "Response → Student", desc: "Answer + cited sources" },
];

const ragFlow = [
  "Student asks a question.",
  "CampusAI searches its knowledge base.",
  "Relevant information is found.",
  "The information is sent as context to the AI model.",
  "AI creates the final response.",
  "Sources are displayed.",
];

export default function About() {
  useReveal();
  return (
    <div className="relative min-h-screen">
      <WaterfallBackground intensity={0.12} />
      <div className="pointer-events-none absolute inset-0 grid-flow opacity-40" />

      <div className="relative mx-auto max-w-4xl px-6 pt-28 pb-16">
        <div className="reveal text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-flow-500/20 bg-flow-500/5 px-3 py-1 text-xs font-medium text-flow-400">
            <Cpu className="h-3.5 w-3.5" /> ARCHITECTURE
          </div>
          <h1 className="mt-3 text-4xl font-bold tracking-tight text-white">
            NVIDIA <span className="text-flow">+ CampusAI</span>
          </h1>
        </div>

        {/* demo notice */}
        <div className="reveal mt-8 flex gap-3 rounded-2xl border border-amber-400/20 bg-amber-400/5 p-5" data-delay="60">
          <Info className="h-5 w-5 shrink-0 text-amber-300" />
          <p className="text-sm text-amber-100/90">
            <strong>The current project runs in Demo Mode.</strong> The architecture is designed
            to connect to NVIDIA-powered inference for production AI responses. In Demo Mode, all
            answers are generated locally from a sample knowledge base and are <em>not</em> produced
            by NVIDIA models.
          </p>
        </div>

        <div className="reveal mt-6 rounded-2xl glass p-6" data-delay="100">
          <p className="text-slate-300">
            CampusAI is designed to use NVIDIA-powered AI inference to process questions and
            generate intelligent responses. The platform combines AI inference with a knowledge
            retrieval system so responses can be grounded in college documents.
          </p>
        </div>

        {/* architecture diagram */}
        <h2 className="reveal mt-12 text-center text-xl font-bold text-white" data-delay="60">
          System Architecture
        </h2>
        <div className="mt-8 flex flex-col items-center gap-0">
          {pipeline.map((p, i) => (
            <div key={p.label} className="flex w-full max-w-md flex-col items-center">
              <div className="reveal flex w-full items-center gap-4 rounded-2xl glass p-4" data-delay={i * 70}>
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-flow-500/10 ring-1 ring-flow-500/20">
                  <p.icon className="h-6 w-6 text-flow-400" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">{p.label}</h4>
                  <p className="text-xs text-slate-400">{p.desc}</p>
                </div>
              </div>
              {i < pipeline.length - 1 && (
                <ArrowDown className="my-1.5 h-5 w-5 text-flow-400/60" />
              )}
            </div>
          ))}
        </div>

        {/* RAG explanation */}
        <h2 className="reveal mt-14 text-center text-xl font-bold text-white" data-delay="60">
          What happens when you ask a question?
        </h2>
        <p className="reveal mt-2 text-center text-sm text-flow-400" data-delay="80">
          Question → Knowledge → AI → Answer
        </p>
        <div className="reveal mt-6 rounded-2xl glass p-6" data-delay="100">
          <ol className="space-y-3">
            {ragFlow.map((step, i) => (
              <li key={i} className="flex items-start gap-3 text-sm text-slate-300">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-flow-500/15 text-xs font-bold text-flow-400">
                  {i + 1}
                </span>
                {step}
              </li>
            ))}
          </ol>
        </div>

        {/* AI mode switch explanation */}
        <div className="mt-12 grid gap-4 sm:grid-cols-3">
          {[
            {
              icon: Layers,
              title: "Service Abstraction",
              text: "AIService → DemoAIService / NVIDIAAIService. Switch via AI_MODE env variable (demo → nvidia).",
            },
            {
              icon: ShieldCheck,
              title: "Secure by Design",
              text: "NVIDIA API keys live only on the FastAPI server, never exposed in frontend code.",
            },
            {
              icon: Database,
              title: "RAG-Ready",
              text: "Demo data can be replaced with embeddings from real PDFs in a vector database.",
            },
          ].map((c, i) => (
            <div key={c.title} className="reveal rounded-2xl glass p-5" data-delay={i * 70}>
              <c.icon className="h-6 w-6 text-flow-400" />
              <h4 className="mt-3 text-sm font-semibold text-white">{c.title}</h4>
              <p className="mt-1 text-xs text-slate-400">{c.text}</p>
            </div>
          ))}
        </div>

        <p className="mt-10 text-center text-xs text-slate-600">
          Not affiliated with, sponsored, certified, or endorsed by NVIDIA. "NVIDIA" is used only
          to describe the intended production inference architecture of this student demo project.
        </p>
      </div>
    </div>
  );
}
