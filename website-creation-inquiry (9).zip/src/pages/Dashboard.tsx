import { Link } from "react-router-dom";
import {
  MessageSquareText,
  BookOpen,
  FileText,
  Briefcase,
  ArrowRight,
  Clock,
  Sparkles,
} from "lucide-react";
import WaterfallBackground from "../components/WaterfallBackground";
import KnowledgeFlow from "../components/KnowledgeFlow";
import { useStats } from "../hooks/useStats";
import { useReveal } from "../hooks/useReveal";
import { subjects, demoEvents } from "../data/knowledgeBase";

export default function Dashboard() {
  const { stats } = useStats();
  useReveal();

  const cards = [
    { label: "AI Questions Asked", value: stats.questions, icon: MessageSquareText, color: "#4ade80" },
    { label: "Study Sessions", value: stats.studySessions, icon: BookOpen, color: "#22d3ee" },
    { label: "Documents Explored", value: stats.documents, icon: FileText, color: "#a78bfa" },
    { label: "Placement Questions", value: stats.placementQuestions, icon: Briefcase, color: "#f59e0b" },
  ];

  return (
    <div className="relative min-h-screen">
      <WaterfallBackground intensity={0.14} />
      <div className="pointer-events-none absolute inset-0 grid-flow opacity-40" />

      <div className="relative mx-auto max-w-6xl px-6 pt-28 pb-16">
        <div className="reveal">
          <h1 className="text-4xl font-bold tracking-tight text-white">
            Welcome back, Student 👋
          </h1>
          <p className="mt-2 text-slate-400">
            Here's your CampusAI knowledge flow at a glance.
          </p>
        </div>

        {/* stats */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c, i) => (
            <div key={c.label} className="reveal rounded-2xl glass p-5" data-delay={i * 60}>
              <div
                className="flex h-11 w-11 items-center justify-center rounded-xl"
                style={{ background: `${c.color}1a`, border: `1px solid ${c.color}33` }}
              >
                <c.icon className="h-5 w-5" style={{ color: c.color }} />
              </div>
              <p className="mt-4 text-3xl font-bold text-white">{c.value}</p>
              <p className="text-xs text-slate-400">{c.label}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          {/* recent questions */}
          <div className="reveal rounded-3xl glass p-6" data-delay="80">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-white">
              <Clock className="h-4 w-4 text-flow-400" /> Recent Questions
            </h3>
            <div className="mt-4 space-y-2">
              {stats.recent.length === 0 ? (
                <p className="text-sm text-slate-500">
                  No questions yet. Head to the{" "}
                  <Link to="/assistant" className="text-flow-400 hover:underline">
                    AI Assistant
                  </Link>
                  .
                </p>
              ) : (
                stats.recent.map((r, i) => (
                  <p key={i} className="truncate rounded-lg bg-white/[0.03] px-3 py-2 text-sm text-slate-300">
                    {r}
                  </p>
                ))
              )}
            </div>
          </div>

          {/* recommended study */}
          <div className="reveal rounded-3xl glass p-6" data-delay="140">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-white">
              <BookOpen className="h-4 w-4 text-flow-400" /> Recommended Study Topics
            </h3>
            <div className="mt-4 flex flex-wrap gap-2">
              {subjects.map((s) => (
                <Link
                  key={s.id}
                  to="/study"
                  className="flex items-center gap-1.5 rounded-xl bg-white/[0.03] px-3 py-1.5 text-xs text-slate-300 ring-1 ring-white/5 transition-colors hover:text-flow-400"
                >
                  <span>{s.icon}</span> {s.name}
                </Link>
              ))}
            </div>
          </div>

          {/* upcoming events */}
          <div className="reveal rounded-3xl glass p-6" data-delay="200">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-white">
              <Sparkles className="h-4 w-4 text-flow-400" /> Upcoming Demo Events
            </h3>
            <div className="mt-4 space-y-2">
              {demoEvents.slice(0, 4).map((e) => (
                <div key={e.id} className="flex items-center gap-3 rounded-lg bg-white/[0.03] px-3 py-2">
                  <span className="text-lg">{e.icon}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm text-white">{e.title}</p>
                    <p className="text-[11px] text-slate-500">{e.date} · {e.time}</p>
                  </div>
                </div>
              ))}
            </div>
            <Link
              to="/events"
              className="mt-4 flex items-center gap-1 text-xs font-medium text-flow-400 hover:underline"
            >
              View all events <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </div>

        {/* knowledge flow */}
        <div className="reveal mt-10" data-delay="120">
          <h3 className="mb-6 text-center text-sm font-semibold uppercase tracking-widest text-flow-400">
            Knowledge Flow
          </h3>
          <KnowledgeFlow />
        </div>
      </div>
    </div>
  );
}
