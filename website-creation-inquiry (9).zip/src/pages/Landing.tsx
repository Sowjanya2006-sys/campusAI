import { Link } from "react-router-dom";
import {
  Sparkles,
  ArrowRight,
  MessageSquareText,
  BookOpen,
  FileText,
  Briefcase,
  Calendar,
  Cpu,
  Search,
  ShieldCheck,
} from "lucide-react";
import WaterfallBackground from "../components/WaterfallBackground";
import KnowledgeFlow from "../components/KnowledgeFlow";
import FunTicker from "../components/FunTicker";
import LiveMotion from "../components/LiveMotion";
import { useReveal } from "../hooks/useReveal";

const features = [
  { icon: MessageSquareText, title: "AI Assistant", desc: "Ask anything about academics, placements and campus life.", to: "/assistant" },
  { icon: BookOpen, title: "AI Study Lab", desc: "Explain, summarize, and generate quizzes on any subject.", to: "/study" },
  { icon: Briefcase, title: "Placement Lab", desc: "Practice interview & aptitude questions with explanations.", to: "/placements" },
  { icon: FileText, title: "Knowledge Library", desc: "Explore demo documents and ask the AI about them.", to: "/documents" },
  { icon: Calendar, title: "Campus Events", desc: "Browse demo workshops, hackathons and seminars.", to: "/events" },
  { icon: Cpu, title: "NVIDIA Architecture", desc: "RAG + inference pipeline ready for production.", to: "/about" },
];

const ragSteps = [
  { icon: Search, title: "1 · Ask", text: "You ask a question in natural language." },
  { icon: Search, title: "2 · Search", text: "CampusAI searches its knowledge base." },
  { icon: FileText, title: "3 · Retrieve", text: "Relevant information is retrieved as context." },
  { icon: Cpu, title: "4 · Generate", text: "AI creates a grounded final response." },
  { icon: ShieldCheck, title: "5 · Cite", text: "Sources are displayed for transparency." },
];

export default function Landing() {
  useReveal();
  return (
    <div>
      {/* ---------- Hero ---------- */}
      <section className="relative min-h-screen overflow-hidden">
        <WaterfallBackground intensity={0.15} />
        <div className="pointer-events-none absolute inset-0 grid-flow opacity-50" />
        <div className="pointer-events-none absolute left-1/2 top-24 h-96 w-96 -translate-x-1/2 rounded-full bg-flow-500/20 blur-[130px] animate-glow" />

        <div className="relative mx-auto flex min-h-screen max-w-5xl flex-col items-center justify-center px-6 pt-28 pb-16 text-center">
          <div className="reveal inline-flex items-center gap-2 rounded-full border border-flow-500/20 bg-flow-500/5 px-4 py-1.5 text-xs font-medium text-slate-200 backdrop-blur">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-flow-400 opacity-70" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-flow-400" />
            </span>
            CampusAI Demo Online
            <span className="mx-1 text-slate-600">|</span>
            <span className="text-flow-400">DEMO MODE</span>
          </div>

          <h1 className="reveal mt-7 text-5xl font-bold leading-[1.05] tracking-tight text-white sm:text-7xl" data-delay="80">
            LET KNOWLEDGE <span className="text-flow">FLOW.</span>
          </h1>

          <p className="reveal mx-auto mt-6 max-w-2xl text-xl font-medium text-slate-200" data-delay="150">
            Your intelligent AI-powered college companion.
          </p>
          <p className="reveal mx-auto mt-3 max-w-xl text-base text-slate-400" data-delay="200">
            Ask questions. Explore knowledge. Learn faster. Prepare smarter.
          </p>

          <div className="reveal mt-9 flex flex-col items-center gap-3 sm:flex-row" data-delay="260">
            <Link
              to="/assistant"
              className="group flex items-center gap-2 rounded-full bg-gradient-to-r from-flow-500 to-cyan-400 px-7 py-3.5 text-sm font-semibold text-[#04120b] shadow-lg shadow-flow-500/30 transition-transform hover:scale-105"
            >
              <Sparkles className="h-4 w-4" /> Ask CampusAI
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              to="/dashboard"
              className="flex items-center gap-2 rounded-full border border-flow-500/20 bg-white/5 px-7 py-3.5 text-sm font-semibold text-white backdrop-blur transition-colors hover:bg-white/10"
            >
              Explore Demo
            </Link>
          </div>

          <p className="reveal mt-7 text-xs font-medium uppercase tracking-widest text-slate-500" data-delay="320">
            Powered by NVIDIA AI Architecture
          </p>
        </div>

        <div className="pointer-events-none absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#04070a] to-transparent" />
        <svg
          className="pointer-events-none absolute bottom-0 left-0 w-full"
          viewBox="0 0 1440 120"
          preserveAspectRatio="none"
          style={{ height: 70 }}
        >
          <path fill="#0a1712" opacity="0.7">
            <animate
              attributeName="d"
              dur="8s"
              repeatCount="indefinite"
              values="
                M0,40 C360,90 720,10 1080,50 C1260,70 1380,40 1440,50 L1440,120 L0,120 Z;
                M0,55 C360,20 720,80 1080,35 C1260,15 1380,55 1440,40 L1440,120 L0,120 Z;
                M0,40 C360,90 720,10 1080,50 C1260,70 1380,40 1440,50 L1440,120 L0,120 Z"
            />
          </path>
          <path fill="#04070a">
            <animate
              attributeName="d"
              dur="6s"
              repeatCount="indefinite"
              values="
                M0,70 C360,40 720,100 1080,70 C1260,55 1380,80 1440,70 L1440,120 L0,120 Z;
                M0,80 C360,110 720,50 1080,85 C1260,100 1380,65 1440,85 L1440,120 L0,120 Z;
                M0,70 C360,40 720,100 1080,70 C1260,55 1380,80 1440,70 L1440,120 L0,120 Z"
            />
          </path>
        </svg>
      </section>

      {/* ---------- Fun facts ticker ---------- */}
      <FunTicker />

      {/* ---------- Knowledge in Motion (lively videos) ---------- */}
      <section className="relative mx-auto max-w-6xl px-6 py-20">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="reveal text-sm font-semibold uppercase tracking-widest text-flow-400">
            Live Visuals
          </h2>
          <p className="reveal mt-3 text-4xl font-bold tracking-tight text-white sm:text-5xl" data-delay="60">
            Knowledge in motion 🌊
          </p>
          <p className="reveal mt-4 text-slate-400" data-delay="120">
            Watch information flow, process and cascade — CampusAI turns learning into a living stream.
          </p>
        </div>
        <div className="mt-12">
          <LiveMotion />
        </div>
      </section>

      {/* ---------- Features ---------- */}
      <section className="relative mx-auto max-w-6xl px-6 py-20">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="reveal text-sm font-semibold uppercase tracking-widest text-flow-400">Explore</h2>
          <p className="reveal mt-3 text-4xl font-bold tracking-tight text-white sm:text-5xl" data-delay="60">
            Everything a student needs
          </p>
        </div>
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <Link
              to={f.to}
              key={f.title}
              className="reveal group relative overflow-hidden rounded-2xl glass p-6 transition-all duration-300 hover:-translate-y-1 hover:border-flow-500/40"
              data-delay={i * 60}
            >
              <div className="absolute -right-8 -top-8 h-28 w-28 rounded-full bg-flow-500/10 opacity-0 blur-2xl transition-opacity group-hover:opacity-100" />
              <div className="relative flex h-12 w-12 items-center justify-center rounded-xl bg-flow-500/10 ring-1 ring-flow-500/20">
                <f.icon className="h-6 w-6 text-flow-400" />
              </div>
              <h3 className="relative mt-4 flex items-center gap-1 text-lg font-semibold text-white">
                {f.title}
                <ArrowRight className="h-4 w-4 text-flow-400 opacity-0 transition-all group-hover:translate-x-1 group-hover:opacity-100" />
              </h3>
              <p className="relative mt-1.5 text-sm text-slate-400">{f.desc}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* ---------- Knowledge Flow ---------- */}
      <section className="relative mx-auto max-w-6xl px-6 py-20">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="reveal text-sm font-semibold uppercase tracking-widest text-cyan-400">The Pipeline</h2>
          <p className="reveal mt-3 text-4xl font-bold tracking-tight text-white sm:text-5xl" data-delay="60">
            How knowledge flows
          </p>
          <p className="reveal mt-4 text-slate-400" data-delay="120">
            Information flows like a waterfall — from your question, through retrieval and AI
            processing, down to a clear answer.
          </p>
        </div>
        <div className="mt-14">
          <KnowledgeFlow />
        </div>
      </section>

      {/* ---------- RAG explanation ---------- */}
      <section className="relative mx-auto max-w-6xl px-6 py-20">
        <div className="reveal overflow-hidden rounded-3xl glass p-8 sm:p-12">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-4xl font-bold tracking-tight text-white">Question → Knowledge → AI → Answer</p>
            <p className="mt-4 text-slate-400">
              CampusAI uses Retrieval-Augmented Generation (RAG) so answers are grounded in
              real documents — not guessed.
            </p>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {ragSteps.map((s, i) => (
              <div key={s.title} className="reveal rounded-2xl bg-white/[0.03] p-5 text-center ring-1 ring-white/5" data-delay={i * 70}>
                <div className="mx-auto flex h-11 w-11 items-center justify-center rounded-xl bg-flow-500/10 ring-1 ring-flow-500/20">
                  <s.icon className="h-5 w-5 text-flow-400" />
                </div>
                <h4 className="mt-3 text-sm font-semibold text-white">{s.title}</h4>
                <p className="mt-1 text-xs text-slate-400">{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
