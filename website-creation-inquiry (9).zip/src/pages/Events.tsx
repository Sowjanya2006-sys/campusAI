import { Calendar, Clock, MapPin } from "lucide-react";
import WaterfallBackground from "../components/WaterfallBackground";
import { demoEvents } from "../data/knowledgeBase";
import { useReveal } from "../hooks/useReveal";

export default function Events() {
  useReveal();
  return (
    <div className="relative min-h-screen">
      <WaterfallBackground intensity={0.1} />
      <div className="pointer-events-none absolute inset-0 grid-flow opacity-40" />

      <div className="relative mx-auto max-w-6xl px-6 pt-28 pb-16">
        <div className="reveal text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-flow-500/20 bg-flow-500/5 px-3 py-1 text-xs font-medium text-flow-400">
            <Calendar className="h-3.5 w-3.5" /> DEMO EVENTS
          </div>
          <h1 className="mt-3 text-4xl font-bold tracking-tight text-white">
            Campus <span className="text-flow">Events</span>
          </h1>
          <p className="mt-2 text-slate-400">
            Sample workshops, hackathons and seminars at NVIDIA Institute of Technology (demo).
          </p>
        </div>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {demoEvents.map((e, i) => (
            <div
              key={e.id}
              className="reveal group relative overflow-hidden rounded-2xl glass p-6 transition-all hover:-translate-y-1.5 hover:border-flow-500/40"
              data-delay={i * 70}
            >
              <div
                className="absolute -right-10 -top-10 h-28 w-28 rounded-full opacity-20 blur-2xl transition-opacity group-hover:opacity-40"
                style={{ background: e.color }}
              />
              <div className="relative flex items-center justify-between">
                <div
                  className="flex h-14 w-14 items-center justify-center rounded-2xl text-2xl animate-float"
                  style={{
                    background: `linear-gradient(135deg, ${e.color}33, ${e.color}11)`,
                    border: `1px solid ${e.color}44`,
                    animationDelay: `${i * 0.3}s`,
                  }}
                >
                  {e.icon}
                </div>
                <span
                  className="rounded-full px-2.5 py-1 text-[11px] font-medium"
                  style={{ background: `${e.color}1a`, color: e.color }}
                >
                  {e.category}
                </span>
              </div>

              <h3 className="relative mt-4 text-lg font-semibold text-white">{e.title}</h3>
              <span className="mt-1 inline-block rounded-full bg-amber-400/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-widest text-amber-300">
                Demo Event
              </span>
              <p className="relative mt-2 text-sm text-slate-400">{e.description}</p>

              <div className="relative mt-4 space-y-1.5 border-t border-white/5 pt-4 text-xs text-slate-300">
                <p className="flex items-center gap-2">
                  <Calendar className="h-3.5 w-3.5 text-flow-400" /> {e.date}
                </p>
                <p className="flex items-center gap-2">
                  <Clock className="h-3.5 w-3.5 text-flow-400" /> {e.time}
                </p>
                <p className="flex items-center gap-2">
                  <MapPin className="h-3.5 w-3.5 text-flow-400" /> {e.venue}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
