import { Link, useNavigate } from "react-router-dom";
import {
  FileText,
  Sparkles,
  UploadCloud,
  CheckCircle2,
  FileType2,
  Trash2,
  Loader2,
  AlertCircle,
} from "lucide-react";
import WaterfallBackground from "../components/WaterfallBackground";
import { demoDocuments } from "../data/knowledgeBase";
import { useReveal } from "../hooks/useReveal";
import { useStats } from "../hooks/useStats";
import { useUploads } from "../hooks/useUploads";
import { useRef, useState } from "react";

export default function Documents() {
  useReveal();
  const { track } = useStats();
  const { uploads, addFiles, remove } = useUploads();
  const navigate = useNavigate();
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  async function handleFiles(files: FileList | File[] | null) {
    if (!files || (files as FileList).length === 0) return;
    setUploading(true);
    try {
      await addFiles(files);
    } finally {
      setUploading(false);
    }
  }

  function askAboutUpload(id: string, name: string) {
    track("document", name);
    navigate(`/assistant?upload=${id}&q=${encodeURIComponent("Summarize this document")}`);
  }

  return (
    <div className="relative min-h-screen">
      <WaterfallBackground intensity={uploading ? 0.6 : 0.1} />
      <div className="pointer-events-none absolute inset-0 grid-flow opacity-40" />

      <div className="relative mx-auto max-w-6xl px-6 pt-28 pb-16">
        <div className="reveal text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-flow-500/20 bg-flow-500/5 px-3 py-1 text-xs font-medium text-flow-400">
            <FileText className="h-3.5 w-3.5" /> DEMO KNOWLEDGE BASE
          </div>
          <h1 className="mt-3 text-4xl font-bold tracking-tight text-white">
            Knowledge <span className="text-flow">Library</span>
          </h1>
          <p className="mt-2 text-slate-400">
            Sample documents indexed for CampusAI. Upload your own and ask the AI about them.
          </p>
        </div>

        {/* ---------- Upload area (functional) ---------- */}
        <div className="reveal mt-10" data-delay="40">
          <h2 className="text-xl font-bold text-white">Add Your Own Knowledge</h2>
          <p className="mt-1 text-sm text-slate-400">
            Upload a file and ask CampusAI about it. <span className="text-flow-400">.txt / .md / .csv</span> are
            read instantly; PDF/DOCX are stored (full text extraction arrives with the backend).
          </p>

          <input
            ref={inputRef}
            type="file"
            multiple
            accept=".txt,.md,.csv,.json,.pdf,.docx,.doc"
            className="hidden"
            onChange={(e) => handleFiles(e.target.files)}
          />

          <div
            role="button"
            tabIndex={0}
            onClick={() => inputRef.current?.click()}
            onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && inputRef.current?.click()}
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              handleFiles(e.dataTransfer.files);
            }}
            className={`mt-4 flex cursor-pointer flex-col items-center justify-center rounded-3xl border-2 border-dashed p-12 text-center transition-all ${
              dragOver
                ? "scale-[1.01] border-flow-500/60 bg-flow-500/10"
                : "border-flow-500/20 bg-white/[0.02] hover:border-flow-500/40 hover:bg-white/[0.04]"
            }`}
          >
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-flow-500/10 ring-1 ring-flow-500/20 animate-float">
              {uploading ? (
                <Loader2 className="h-8 w-8 animate-spin text-flow-400" />
              ) : (
                <UploadCloud className="h-8 w-8 text-flow-400" />
              )}
            </div>
            <p className="mt-4 font-medium text-white">
              {uploading ? "Reading your file…" : "Click to browse or drag & drop"}
            </p>
            <p className="mt-1 text-sm text-slate-400">Supports TXT, MD, CSV, JSON, PDF, DOCX</p>
            <span className="mt-4 rounded-xl bg-gradient-to-r from-flow-500 to-cyan-400 px-4 py-2 text-sm font-semibold text-[#04120b]">
              Choose file
            </span>
          </div>
        </div>

        {/* ---------- Your uploads ---------- */}
        {uploads.length > 0 && (
          <div className="mt-10">
            <h2 className="text-lg font-bold text-white">Your Uploads ({uploads.length})</h2>
            <div className="mt-4 grid gap-5 sm:grid-cols-2">
              {uploads.map((d) => (
                <div
                  key={d.id}
                  className="group relative overflow-hidden rounded-2xl glass p-6 transition-all hover:-translate-y-1 hover:border-flow-500/40"
                >
                  <div className="relative flex items-start gap-4">
                    <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-cyan-500/10 ring-1 ring-cyan-500/20">
                      <FileText className="h-7 w-7 text-cyan-400" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="truncate text-base font-semibold text-white">{d.name}</h3>
                      <p className="mt-1 line-clamp-2 text-xs text-slate-400">{d.summary}</p>
                      <div className="mt-3 flex flex-wrap gap-2 text-[11px] text-slate-400">
                        <span className="inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-0.5">
                          <FileType2 className="h-3 w-3" /> {d.type}
                        </span>
                        <span className="rounded-full bg-white/5 px-2 py-0.5">{d.size}</span>
                        <span className="rounded-full bg-white/5 px-2 py-0.5">~{d.pages} pages</span>
                        {d.status === "Indexed" ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-flow-500/10 px-2 py-0.5 text-flow-400">
                            <CheckCircle2 className="h-3 w-3" /> {d.status}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded-full bg-amber-400/10 px-2 py-0.5 text-amber-300">
                            <AlertCircle className="h-3 w-3" /> {d.status}
                          </span>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => remove(d.id)}
                      className="rounded-lg p-1.5 text-slate-500 transition-colors hover:bg-red-500/10 hover:text-red-400"
                      title="Remove"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <button
                    onClick={() => askAboutUpload(d.id, d.name)}
                    className="relative mt-5 flex w-full items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-flow-500 to-cyan-400 px-4 py-2.5 text-sm font-semibold text-[#04120b] transition-transform hover:scale-[1.02]"
                  >
                    <Sparkles className="h-4 w-4" /> Ask AI About This Document
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ---------- Demo documents ---------- */}
        <div className="mt-10">
          <h2 className="text-lg font-bold text-white">Demo Documents</h2>
          <div className="mt-4 grid gap-5 sm:grid-cols-2">
            {demoDocuments.map((d, i) => (
              <div
                key={d.id}
                className="reveal group relative overflow-hidden rounded-2xl glass p-6 transition-all hover:-translate-y-1 hover:border-flow-500/40"
                data-delay={i * 70}
              >
                <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-flow-500/10 opacity-0 blur-2xl transition-opacity group-hover:opacity-100" />
                <div className="relative flex items-start gap-4">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-flow-500/10 ring-1 ring-flow-500/20">
                    <FileText className="h-7 w-7 text-flow-400" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate text-base font-semibold text-white">{d.name}</h3>
                    <p className="mt-1 line-clamp-2 text-xs text-slate-400">{d.summary}</p>
                    <div className="mt-3 flex flex-wrap gap-2 text-[11px] text-slate-400">
                      <span className="inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-0.5">
                        <FileType2 className="h-3 w-3" /> {d.type}
                      </span>
                      <span className="rounded-full bg-white/5 px-2 py-0.5">{d.size}</span>
                      <span className="rounded-full bg-white/5 px-2 py-0.5">{d.pages} pages</span>
                      <span className="inline-flex items-center gap-1 rounded-full bg-flow-500/10 px-2 py-0.5 text-flow-400">
                        <CheckCircle2 className="h-3 w-3" /> {d.status}
                      </span>
                    </div>
                  </div>
                </div>
                <Link
                  to={`/assistant?doc=${d.id}&q=${encodeURIComponent("Summarize " + d.name)}`}
                  onClick={() => track("document", d.name)}
                  className="relative mt-5 flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-flow-500 to-cyan-400 px-4 py-2.5 text-sm font-semibold text-[#04120b] transition-transform hover:scale-[1.02]"
                >
                  <Sparkles className="h-4 w-4" /> Ask AI About This Document
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
