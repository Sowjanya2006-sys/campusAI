/**
 * DEMO KNOWLEDGE BASE — NVIDIA Institute of Technology (fictional)
 * ----------------------------------------------------------------
 * All information below is SAMPLE / DEMO data for demonstration only.
 * It is NOT real college information. In production this data would be
 * replaced by embeddings generated from real college PDFs/documents,
 * retrieved via a RAG (Retrieval Augmented Generation) pipeline.
 */

export type Subject = {
  id: string;
  name: string;
  icon: string;
  color: string;
  summary: string;
  explanation: string;
  topics: string[];
  questions: { q: string; a: string }[];
};

export const collegeInfo = {
  name: "NVIDIA Institute of Technology",
  tagline: "A fictional institute used for the CampusAI demo.",
  overview:
    "NVIDIA Institute of Technology (demo) is a fictional engineering college created for the CampusAI demonstration. It offers undergraduate programs in computing and AI with a focus on hands-on, project-based learning.",
  departments: [
    "Computer Science & Engineering",
    "Artificial Intelligence & Machine Learning (AIML)",
    "Information Technology",
    "Electronics & Communication",
    "Data Science",
  ],
  programs: [
    "B.Tech in AIML (4 years)",
    "B.Tech in Computer Science (4 years)",
    "B.Tech in Data Science (4 years)",
    "M.Tech in AI (2 years)",
  ],
  facilities: [
    "Central Digital Library with 40k+ demo e-resources",
    "High-performance GPU computing lab (demo)",
    "Innovation & Incubation Center",
    "Smart classrooms with recording",
    "Sports complex and student lounge",
  ],
  library: {
    hours: "Mon–Sat, 8:00 AM – 10:00 PM (demo hours)",
    resources: "40,000+ demo e-books, journals and video lectures",
    services: "Digital catalog, group study pods, and a quiet reading zone",
  },
  labs: [
    "GPU / AI Compute Lab (demo)",
    "Data Structures & Algorithms Lab",
    "Networking Lab",
    "Database Systems Lab",
    "IoT & Embedded Lab",
  ],
  clubs: [
    "AI & ML Club",
    "Competitive Coding Club",
    "Open Source Society",
    "Robotics Club",
    "Design & UX Club",
  ],
};

export const subjects: Subject[] = [
  {
    id: "python",
    name: "Python",
    icon: "🐍",
    color: "#4ade80",
    summary:
      "Python is a high-level, readable programming language widely used in AI, data science, automation and web development.",
    explanation:
      "Python is an interpreted, dynamically-typed language known for clean syntax. Core building blocks include **variables**, **data types** (int, float, str, list, tuple, dict, set), **control flow** (if/for/while), **functions**, and **OOP** (classes & objects). Its huge ecosystem — NumPy, Pandas, scikit-learn, TensorFlow, PyTorch — makes it the default language for machine learning.",
    topics: [
      "Variables & data types",
      "Lists, tuples, dictionaries, sets",
      "Functions & scope",
      "Object Oriented Programming",
      "Exception handling",
      "File handling",
      "Modules & packages",
      "Comprehensions & generators",
    ],
    questions: [
      {
        q: "What is a Python function?",
        a: "A function is a reusable block of code defined with `def`. It can accept parameters, run logic, and return a value using `return`.",
      },
      {
        q: "What is the difference between a list and a tuple?",
        a: "Lists are mutable (changeable) and use `[]`; tuples are immutable and use `()`. Tuples are faster and safer for fixed data.",
      },
      {
        q: "What is a dictionary?",
        a: "A dictionary stores key-value pairs using `{}`, allowing fast lookups by key, e.g. `student = {'name': 'Asha', 'cgpa': 8.6}`.",
      },
    ],
  },
  {
    id: "java",
    name: "Java",
    icon: "☕",
    color: "#f59e0b",
    summary:
      "Java is a robust, object-oriented, platform-independent language used in enterprise, Android and backend systems.",
    explanation:
      "Java follows a **write once, run anywhere** philosophy using the JVM. Key concepts include **classes & objects**, the four **OOP pillars** (encapsulation, inheritance, polymorphism, abstraction), **exception handling**, **collections framework**, and **multithreading**. Strong typing and mature tooling make it popular for large systems.",
    topics: [
      "OOP pillars",
      "Classes, objects & constructors",
      "Inheritance & polymorphism",
      "Interfaces & abstract classes",
      "Collections framework",
      "Exception handling",
      "Multithreading",
    ],
    questions: [
      {
        q: "What are the four pillars of OOP in Java?",
        a: "Encapsulation, Inheritance, Polymorphism and Abstraction.",
      },
      {
        q: "Difference between an interface and abstract class?",
        a: "An interface declares method signatures (100% abstraction by default); an abstract class can mix abstract and concrete methods and hold state.",
      },
    ],
  },
  {
    id: "dbms",
    name: "DBMS",
    icon: "🗄️",
    color: "#38bdf8",
    summary:
      "Database Management Systems store, organize and retrieve data efficiently using models like the relational model.",
    explanation:
      "A DBMS manages data with **tables** (relations), **keys** (primary, foreign), and **SQL** for queries. Important ideas: **normalization** (1NF–3NF/BCNF) to reduce redundancy, **ACID** transaction properties, **indexing** for speed, and **joins** to combine tables. SQL commands split into DDL, DML, DCL and TCL.",
    topics: [
      "Relational model & keys",
      "SQL (DDL, DML, DCL, TCL)",
      "Normalization (1NF–BCNF)",
      "Joins",
      "Transactions & ACID",
      "Indexing",
      "ER diagrams",
    ],
    questions: [
      {
        q: "What is normalization?",
        a: "Normalization organizes tables to reduce redundancy and anomalies by splitting data into related tables (1NF, 2NF, 3NF, BCNF).",
      },
      {
        q: "What does ACID stand for?",
        a: "Atomicity, Consistency, Isolation, Durability — the properties that guarantee reliable database transactions.",
      },
    ],
  },
  {
    id: "ds",
    name: "Data Structures",
    icon: "🌳",
    color: "#a78bfa",
    summary:
      "Data structures organize data for efficient access and modification — the backbone of algorithm design.",
    explanation:
      "Core structures: **arrays**, **linked lists**, **stacks** (LIFO), **queues** (FIFO), **trees** (BST, heaps), **graphs**, and **hash tables**. Choosing the right structure impacts **time & space complexity** (Big-O). For example, hash tables give O(1) average lookups while balanced BSTs give O(log n).",
    topics: [
      "Arrays & strings",
      "Linked lists",
      "Stacks & queues",
      "Trees & BST",
      "Heaps & priority queues",
      "Graphs & traversals (BFS/DFS)",
      "Hashing",
      "Time & space complexity (Big-O)",
    ],
    questions: [
      {
        q: "What is the difference between a stack and a queue?",
        a: "A stack is LIFO (last-in first-out); a queue is FIFO (first-in first-out).",
      },
      {
        q: "What is Big-O notation?",
        a: "Big-O describes how an algorithm's running time or space grows with input size, e.g. O(1), O(log n), O(n), O(n²).",
      },
    ],
  },
  {
    id: "os",
    name: "Operating Systems",
    icon: "🖥️",
    color: "#fb7185",
    summary:
      "An OS manages hardware and software resources, providing services like process, memory and file management.",
    explanation:
      "An operating system handles **processes & threads**, **CPU scheduling** (FCFS, SJF, Round Robin), **memory management** (paging, segmentation, virtual memory), **synchronization** (semaphores, mutex), **deadlocks**, and **file systems**. It acts as the bridge between user applications and hardware.",
    topics: [
      "Processes & threads",
      "CPU scheduling algorithms",
      "Deadlocks",
      "Memory management & paging",
      "Virtual memory",
      "Synchronization (semaphores)",
      "File systems",
    ],
    questions: [
      {
        q: "What is a deadlock?",
        a: "A deadlock occurs when processes wait indefinitely for resources held by each other. Four conditions: mutual exclusion, hold & wait, no preemption, circular wait.",
      },
      {
        q: "What is virtual memory?",
        a: "Virtual memory lets a system use disk space as an extension of RAM, allowing programs larger than physical memory to run via paging.",
      },
    ],
  },
  {
    id: "cn",
    name: "Computer Networks",
    icon: "🌐",
    color: "#22d3ee",
    summary:
      "Computer networks connect devices to share data using protocols organized in layered models.",
    explanation:
      "Networking is organized by the **OSI (7-layer)** and **TCP/IP** models. Key topics: **IP addressing & subnetting**, **TCP vs UDP**, **routing**, **DNS**, **HTTP/HTTPS**, and the **client-server** model. Reliable delivery, congestion control and error handling are central concerns.",
    topics: [
      "OSI & TCP/IP models",
      "IP addressing & subnetting",
      "TCP vs UDP",
      "Routing & switching",
      "DNS & DHCP",
      "HTTP / HTTPS",
      "Network security basics",
    ],
    questions: [
      {
        q: "What is the difference between TCP and UDP?",
        a: "TCP is connection-oriented and reliable (ordered, acknowledged); UDP is connectionless, faster, but does not guarantee delivery.",
      },
      {
        q: "What are the layers of the OSI model?",
        a: "Physical, Data Link, Network, Transport, Session, Presentation, Application.",
      },
    ],
  },
  {
    id: "ml",
    name: "Machine Learning",
    icon: "🤖",
    color: "#34d399",
    summary:
      "Machine Learning builds systems that learn patterns from data to make predictions or decisions.",
    explanation:
      "ML has three main paradigms: **supervised** (labeled data — regression, classification), **unsupervised** (clustering, dimensionality reduction), and **reinforcement** learning. A typical workflow: collect data → preprocess → train model → evaluate (accuracy, precision, recall) → deploy. Deep learning uses **neural networks** and benefits greatly from GPU acceleration.",
    topics: [
      "Supervised vs unsupervised learning",
      "Regression & classification",
      "Overfitting & regularization",
      "Train/test split & cross-validation",
      "Evaluation metrics",
      "Neural networks basics",
      "Feature engineering",
    ],
    questions: [
      {
        q: "What is overfitting?",
        a: "Overfitting is when a model learns training data too well (including noise) and performs poorly on new data. Fixes: more data, regularization, simpler models.",
      },
      {
        q: "What is supervised learning?",
        a: "Supervised learning trains on labeled examples (input → known output) to predict outputs for new inputs, e.g. spam detection.",
      },
    ],
  },
];

export const aimlProgram = {
  name: "B.Tech in Artificial Intelligence & Machine Learning (Demo)",
  coreSubjects: [
    "Python Programming",
    "Data Structures",
    "DBMS",
    "Operating Systems",
    "Computer Networks",
    "Machine Learning",
  ],
  description:
    "The demo AIML program blends programming fundamentals with AI specialization, culminating in a capstone AI project.",
};

export const placementCategories = [
  { id: "python", name: "Python", topics: ["Syntax", "OOP", "Data handling", "Problem solving"] },
  { id: "java", name: "Java", topics: ["OOP", "Collections", "Exceptions", "Threads"] },
  { id: "sql", name: "SQL", topics: ["Joins", "Aggregations", "Subqueries", "Indexes"] },
  { id: "dbms", name: "DBMS", topics: ["Normalization", "Transactions", "Keys", "ER model"] },
  { id: "dsa", name: "DSA", topics: ["Arrays", "Trees", "Graphs", "Dynamic programming"] },
  { id: "os", name: "OS", topics: ["Scheduling", "Deadlocks", "Memory", "Synchronization"] },
  { id: "cn", name: "CN", topics: ["OSI model", "TCP/IP", "Routing", "Protocols"] },
  { id: "aptitude", name: "Aptitude", topics: ["Quant", "Logical", "Verbal", "Data interpretation"] },
  { id: "interview", name: "Interview", topics: ["HR questions", "Behavioral", "Projects", "Communication"] },
];

export const placementResources = {
  preparation: [
    "Revise core CS subjects: DSA, DBMS, OS, CN.",
    "Practice 2–3 coding problems daily.",
    "Build 1–2 solid projects you can explain deeply.",
    "Prepare a crisp, honest resume (1 page).",
    "Do mock interviews to build confidence.",
  ],
  technicalTopics: [
    "Data Structures & Algorithms",
    "Object Oriented Programming",
    "Database & SQL queries",
    "Operating Systems concepts",
    "Computer Networks fundamentals",
    "System design basics (for advanced roles)",
  ],
  aptitudeTopics: [
    "Quantitative aptitude (percentages, ratios, time & work)",
    "Logical reasoning (series, puzzles, seating)",
    "Verbal ability (grammar, comprehension)",
    "Data interpretation (charts, tables)",
  ],
  companyCategories: [
    "Product-based companies (demo category)",
    "Service-based companies (demo category)",
    "Startups (demo category)",
    "Core / research roles (demo category)",
  ],
  mockInterview:
    "Demo mock interviews simulate a 30-minute round: 10 min DSA, 10 min core subjects, 10 min HR/projects. Feedback focuses on correctness, clarity and communication.",
};

// Sample placement MCQs per category (demo)
export const placementQuestions: Record<
  string,
  { question: string; options: string[]; answer: number; explanation: string; difficulty: string }[]
> = {
  python: [
    {
      question: "Which data type is immutable in Python?",
      options: ["list", "dict", "tuple", "set"],
      answer: 2,
      explanation: "Tuples are immutable — their contents cannot be changed after creation.",
      difficulty: "Beginner",
    },
    {
      question: "What does the `len()` function return for a dictionary?",
      options: ["Number of keys", "Number of values", "Total characters", "Memory size"],
      answer: 0,
      explanation: "`len(dict)` returns the number of key-value pairs (keys).",
      difficulty: "Beginner",
    },
  ],
  dsa: [
    {
      question: "What is the time complexity of binary search?",
      options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"],
      answer: 1,
      explanation: "Binary search halves the search space each step → O(log n).",
      difficulty: "Intermediate",
    },
    {
      question: "Which structure uses FIFO ordering?",
      options: ["Stack", "Queue", "Tree", "Graph"],
      answer: 1,
      explanation: "A queue follows First-In-First-Out (FIFO).",
      difficulty: "Beginner",
    },
  ],
  sql: [
    {
      question: "Which JOIN returns only matching rows from both tables?",
      options: ["LEFT JOIN", "RIGHT JOIN", "INNER JOIN", "FULL JOIN"],
      answer: 2,
      explanation: "INNER JOIN returns rows with matching keys in both tables.",
      difficulty: "Beginner",
    },
  ],
  dbms: [
    {
      question: "Which normal form removes transitive dependency?",
      options: ["1NF", "2NF", "3NF", "BCNF"],
      answer: 2,
      explanation: "3NF removes transitive dependencies between non-key attributes.",
      difficulty: "Intermediate",
    },
  ],
  aptitude: [
    {
      question: "If a train travels 60 km in 45 minutes, its speed is:",
      options: ["70 km/h", "80 km/h", "75 km/h", "90 km/h"],
      answer: 1,
      explanation: "60 km in 0.75 h → 60 / 0.75 = 80 km/h.",
      difficulty: "Beginner",
    },
  ],
  os: [
    {
      question: "Which scheduling can cause starvation?",
      options: ["Round Robin", "FCFS", "Priority (non-preemptive)", "None"],
      answer: 2,
      explanation: "Low-priority processes may wait indefinitely under priority scheduling → starvation.",
      difficulty: "Intermediate",
    },
  ],
  cn: [
    {
      question: "Which protocol is connectionless?",
      options: ["TCP", "UDP", "FTP", "HTTP"],
      answer: 1,
      explanation: "UDP is connectionless and does not guarantee delivery.",
      difficulty: "Beginner",
    },
  ],
  java: [
    {
      question: "Which keyword prevents inheritance of a class in Java?",
      options: ["static", "final", "const", "sealed"],
      answer: 1,
      explanation: "A `final` class cannot be extended.",
      difficulty: "Beginner",
    },
  ],
  interview: [
    {
      question: "Best approach for 'Tell me about yourself'?",
      options: [
        "Read your resume aloud",
        "Give a structured 60-90s summary",
        "Talk about hobbies only",
        "Stay silent",
      ],
      answer: 1,
      explanation: "A concise, structured summary (present → past → future goals) works best.",
      difficulty: "Beginner",
    },
  ],
};

export type DemoDoc = {
  id: string;
  name: string;
  type: string;
  size: string;
  pages: number;
  status: "Indexed" | "Processing";
  subjectId?: string;
  summary: string;
};

export const demoDocuments: DemoDoc[] = [
  {
    id: "aiml-syllabus",
    name: "Demo AIML Semester Syllabus.pdf",
    type: "PDF",
    size: "1.4 MB",
    pages: 24,
    status: "Indexed",
    summary:
      "Sample semester syllabus for the demo AIML program covering Python, Data Structures, DBMS, OS, CN and Machine Learning with unit-wise topics and credits.",
  },
  {
    id: "python-notes",
    name: "Demo Python Study Notes.pdf",
    type: "PDF",
    size: "870 KB",
    pages: 16,
    status: "Indexed",
    subjectId: "python",
    summary:
      "Concise Python notes: data types, functions, OOP, exception handling, file I/O and common interview questions with examples.",
  },
  {
    id: "placement-guide",
    name: "Demo Placement Preparation Guide.pdf",
    type: "PDF",
    size: "2.1 MB",
    pages: 38,
    status: "Indexed",
    summary:
      "Sample placement roadmap: technical topics, aptitude prep, resume tips, mock interview structure and demo company categories.",
  },
  {
    id: "handbook",
    name: "Demo College Handbook.pdf",
    type: "PDF",
    size: "3.0 MB",
    pages: 52,
    status: "Indexed",
    summary:
      "Sample handbook for NVIDIA Institute of Technology (demo): departments, facilities, library rules, clubs and academic calendar.",
  },
];

export type DemoEvent = {
  id: string;
  title: string;
  category: string;
  date: string;
  time: string;
  venue: string;
  icon: string;
  color: string;
  description: string;
};

export const demoEvents: DemoEvent[] = [
  {
    id: "ai-workshop",
    title: "AI & ML Workshop",
    category: "Workshop",
    date: "Mar 12",
    time: "10:00 AM",
    venue: "GPU Compute Lab (Demo)",
    icon: "🤖",
    color: "#34d399",
    description:
      "Hands-on demo workshop covering ML fundamentals, model training and GPU-accelerated inference concepts.",
  },
  {
    id: "hackathon",
    title: "Campus Hackathon",
    category: "Hackathon",
    date: "Mar 20",
    time: "9:00 AM",
    venue: "Innovation Center (Demo)",
    icon: "⚡",
    color: "#4ade80",
    description:
      "A 24-hour demo hackathon where teams build AI-powered prototypes and pitch to a panel of mentors.",
  },
  {
    id: "coding-comp",
    title: "Python Coding Challenge",
    category: "Competition",
    date: "Mar 26",
    time: "2:00 PM",
    venue: "DSA Lab (Demo)",
    icon: "🏆",
    color: "#22d3ee",
    description:
      "Competitive coding contest with algorithmic problems of increasing difficulty. Demo event for practice.",
  },
  {
    id: "genai-seminar",
    title: "Generative AI Seminar",
    category: "Seminar",
    date: "Apr 03",
    time: "11:00 AM",
    venue: "Auditorium (Demo)",
    icon: "🧠",
    color: "#a78bfa",
    description:
      "An introductory demo seminar on generative AI, large language models and responsible AI usage.",
  },
  {
    id: "club-event",
    title: "Technical Club Meetup",
    category: "Club Event",
    date: "Apr 09",
    time: "4:30 PM",
    venue: "Student Lounge (Demo)",
    icon: "🎯",
    color: "#f59e0b",
    description:
      "Monthly demo meetup of the AI & ML Club with lightning talks, project demos and networking.",
  },
];
