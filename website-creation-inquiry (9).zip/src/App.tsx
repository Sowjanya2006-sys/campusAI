import { HashRouter, Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Mascot from "./components/Mascot";
import Landing from "./pages/Landing";
import Assistant from "./pages/Assistant";
import Study from "./pages/Study";
import Placements from "./pages/Placements";
import Documents from "./pages/Documents";
import Events from "./pages/Events";
import Dashboard from "./pages/Dashboard";
import About from "./pages/About";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <HashRouter>
      <ScrollToTop />
      <div className="min-h-screen bg-[#04070a] text-slate-200 antialiased">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/assistant" element={<Assistant />} />
            <Route path="/study" element={<Study />} />
            <Route path="/placements" element={<Placements />} />
            <Route path="/documents" element={<Documents />} />
            <Route path="/events" element={<Events />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/about" element={<About />} />
          </Routes>
        </main>
        <Footer />
        <Mascot />
      </div>
    </HashRouter>
  );
}
