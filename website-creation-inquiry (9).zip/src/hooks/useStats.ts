import { useCallback, useEffect, useState } from "react";

export type Stats = {
  questions: number;
  studySessions: number;
  documents: number;
  placementQuestions: number;
  recent: string[];
};

const KEY = "campusai_stats";
const initial: Stats = {
  questions: 0,
  studySessions: 0,
  documents: 0,
  placementQuestions: 0,
  recent: [],
};

function read(): Stats {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...initial, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return initial;
}

// simple global event so multiple components stay in sync
const listeners = new Set<() => void>();
function emit() {
  listeners.forEach((l) => l());
}

export function useStats() {
  const [stats, setStats] = useState<Stats>(read);

  useEffect(() => {
    const l = () => setStats(read());
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }, []);

  const update = useCallback((patch: Partial<Stats> | ((s: Stats) => Stats)) => {
    const current = read();
    const next =
      typeof patch === "function" ? patch(current) : { ...current, ...patch };
    localStorage.setItem(KEY, JSON.stringify(next));
    emit();
  }, []);

  const track = useCallback(
    (type: "question" | "study" | "document" | "placement", label?: string) => {
      const current = read();
      const next = { ...current };
      if (type === "question") next.questions += 1;
      if (type === "study") next.studySessions += 1;
      if (type === "document") next.documents += 1;
      if (type === "placement") next.placementQuestions += 1;
      if (label) next.recent = [label, ...current.recent].slice(0, 6);
      localStorage.setItem(KEY, JSON.stringify(next));
      emit();
    },
    []
  );

  return { stats, update, track };
}
