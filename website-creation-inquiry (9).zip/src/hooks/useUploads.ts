import { useCallback, useEffect, useState } from "react";

export type UploadedDoc = {
  id: string;
  name: string;
  type: string; // PDF / DOCX / TXT
  size: string; // human readable
  pages: number; // estimated
  status: "Indexed" | "Text not extracted";
  summary: string;
  text?: string; // extracted text (TXT only in the demo)
  addedAt: number;
};

const KEY = "campusai_uploads";

function read(): UploadedDoc[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    /* ignore */
  }
  return [];
}

const listeners = new Set<() => void>();
function emit() {
  listeners.forEach((l) => l());
}

export function humanSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export function useUploads() {
  const [uploads, setUploads] = useState<UploadedDoc[]>(read);

  useEffect(() => {
    const l = () => setUploads(read());
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }, []);

  const save = useCallback((docs: UploadedDoc[]) => {
    localStorage.setItem(KEY, JSON.stringify(docs));
    emit();
  }, []);

  const addFiles = useCallback(
    (files: FileList | File[]): Promise<UploadedDoc[]> => {
      const arr = Array.from(files);
      return Promise.all(
        arr.map(
          (file) =>
            new Promise<UploadedDoc>((resolve) => {
              const ext = (file.name.split(".").pop() || "").toUpperCase();
              const isText = /txt|md|csv|json/i.test(ext);
              const base: UploadedDoc = {
                id: `u_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
                name: file.name,
                type: ext || "FILE",
                size: humanSize(file.size),
                pages: Math.max(1, Math.round(file.size / 2400)),
                status: isText ? "Indexed" : "Text not extracted",
                summary: isText
                  ? "Your uploaded text document — indexed for CampusAI (demo)."
                  : "Uploaded file. Full text extraction for PDF/DOCX arrives with the backend.",
                addedAt: Date.now(),
              };
              if (isText) {
                const reader = new FileReader();
                reader.onload = () => {
                  const text = String(reader.result || "");
                  base.text = text.slice(0, 20000); // cap for demo
                  const firstLine =
                    text.split("\n").find((l) => l.trim().length > 0)?.trim() || "";
                  if (firstLine)
                    base.summary = `Starts with: "${firstLine.slice(0, 90)}${
                      firstLine.length > 90 ? "…" : ""
                    }"`;
                  resolve(base);
                };
                reader.onerror = () => resolve(base);
                reader.readAsText(file);
              } else {
                resolve(base);
              }
            })
        )
      ).then((newDocs) => {
        const next = [...newDocs, ...read()];
        save(next);
        return newDocs;
      });
    },
    [save]
  );

  const remove = useCallback(
    (id: string) => {
      save(read().filter((d) => d.id !== id));
    },
    [save]
  );

  const getById = useCallback((id: string) => read().find((d) => d.id === id), []);

  return { uploads, addFiles, remove, getById };
}
