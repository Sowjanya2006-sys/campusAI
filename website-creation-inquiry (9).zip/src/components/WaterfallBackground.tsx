import { useEffect, useRef } from "react";

type Props = {
  /** intensity 0..1 — increases when the AI is "processing" */
  intensity?: number;
  className?: string;
};

type Particle = {
  x: number;
  y: number;
  vy: number;
  vx: number;
  r: number;
  life: number;
  hue: number;
  type: "drop" | "mist";
};

/**
 * WaterfallBackground
 * A lightweight <canvas> knowledge-flow / waterfall visualization.
 * - Flowing vertical streams
 * - Falling data particles + soft mist
 * - Reacts subtly to the mouse; click creates a ripple
 * - `intensity` boosts flow speed while the AI is processing
 */
export default function WaterfallBackground({ intensity = 0, className = "" }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const intensityRef = useRef(intensity);
  intensityRef.current = intensity;

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    let raf = 0;
    let w = 0;
    let h = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const mouse = { x: -999, y: -999, active: false };
    const ripples: { x: number; y: number; r: number; a: number }[] = [];
    const particles: Particle[] = [];
    const streams: { x: number; speed: number; width: number; offset: number }[] = [];

    const isMobile = window.innerWidth < 768;
    const streamCount = isMobile ? 7 : 14;
    const maxParticles = isMobile ? 70 : 150;

    function resize() {
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      streams.length = 0;
      for (let i = 0; i < streamCount; i++) {
        streams.push({
          x: (w / streamCount) * i + Math.random() * (w / streamCount),
          speed: 0.6 + Math.random() * 1.4,
          width: 1 + Math.random() * 2.5,
          offset: Math.random() * 1000,
        });
      }
    }

    function spawn() {
      const boost = intensityRef.current;
      const target = maxParticles * (0.5 + boost * 0.5);
      while (particles.length < target) {
        const mist = Math.random() > 0.55;
        particles.push({
          x: Math.random() * w,
          y: Math.random() * -h,
          vy: (mist ? 0.4 : 1.6) * (1 + boost) + Math.random() * 1.5,
          vx: (Math.random() - 0.5) * 0.4,
          r: mist ? 1 + Math.random() * 2.5 : 0.8 + Math.random() * 1.8,
          life: 1,
          hue: 140 + Math.random() * 40, // green -> teal
          type: mist ? "mist" : "drop",
        });
      }
    }

    function tick(t: number) {
      const boost = intensityRef.current;
      ctx.clearRect(0, 0, w, h);

      // vertical flowing streams
      ctx.lineCap = "round";
      for (const s of streams) {
        const speed = s.speed * (1 + boost * 1.2);
        s.offset += speed * 2;
        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, "rgba(74,222,128,0)");
        grad.addColorStop(0.4, `rgba(74,222,128,${0.06 + boost * 0.08})`);
        grad.addColorStop(0.9, `rgba(34,211,238,${0.05 + boost * 0.07})`);
        grad.addColorStop(1, "rgba(34,211,238,0)");
        ctx.strokeStyle = grad;
        ctx.lineWidth = s.width;
        ctx.beginPath();
        const sway = Math.sin((s.offset + t * 0.02) * 0.01) * (isMobile ? 6 : 12);
        const mouseInfluence =
          mouse.active && Math.abs(mouse.x - s.x) < 120
            ? (mouse.x - s.x) * 0.05
            : 0;
        for (let y = 0; y <= h; y += 24) {
          const x =
            s.x +
            Math.sin((y + s.offset) * 0.012) * (isMobile ? 5 : 10) +
            sway +
            mouseInfluence;
          if (y === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }

      // particles
      spawn();
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.y += p.vy * (1 + boost * 0.6);
        p.x += p.vx;

        // gentle mouse repulsion / attraction
        if (mouse.active) {
          const dx = p.x - mouse.x;
          const dy = p.y - mouse.y;
          const d2 = dx * dx + dy * dy;
          if (d2 < 9000) {
            const f = (9000 - d2) / 9000;
            p.x += (dx / (Math.sqrt(d2) + 0.1)) * f * 1.5;
          }
        }

        if (p.y > h + 10) {
          particles.splice(i, 1);
          continue;
        }

        const alpha =
          p.type === "mist" ? 0.18 + boost * 0.15 : 0.5 + boost * 0.3;
        ctx.beginPath();
        ctx.fillStyle = `hsla(${p.hue}, 80%, 65%, ${alpha})`;
        if (p.type === "drop") {
          ctx.shadowColor = "rgba(74,222,128,0.6)";
          ctx.shadowBlur = 6 + boost * 8;
        } else {
          ctx.shadowBlur = 0;
        }
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.shadowBlur = 0;

      // cursor glow
      if (mouse.active) {
        const g = ctx.createRadialGradient(
          mouse.x,
          mouse.y,
          0,
          mouse.x,
          mouse.y,
          140
        );
        g.addColorStop(0, "rgba(74,222,128,0.10)");
        g.addColorStop(1, "rgba(74,222,128,0)");
        ctx.fillStyle = g;
        ctx.fillRect(mouse.x - 140, mouse.y - 140, 280, 280);
      }

      // ripples
      for (let i = ripples.length - 1; i >= 0; i--) {
        const rp = ripples[i];
        rp.r += 4;
        rp.a -= 0.02;
        if (rp.a <= 0) {
          ripples.splice(i, 1);
          continue;
        }
        ctx.beginPath();
        ctx.strokeStyle = `rgba(74,222,128,${rp.a})`;
        ctx.lineWidth = 2;
        ctx.arc(rp.x, rp.y, rp.r, 0, Math.PI * 2);
        ctx.stroke();
      }

      raf = requestAnimationFrame(tick);
    }

    function onMove(e: MouseEvent) {
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
      mouse.active = true;
    }
    function onLeave() {
      mouse.active = false;
      mouse.x = -999;
      mouse.y = -999;
    }
    function onClick(e: MouseEvent) {
      const rect = canvas.getBoundingClientRect();
      ripples.push({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        r: 0,
        a: 0.6,
      });
    }
    function onTouch(e: TouchEvent) {
      const rect = canvas.getBoundingClientRect();
      const tch = e.touches[0];
      if (tch) {
        mouse.x = tch.clientX - rect.left;
        mouse.y = tch.clientY - rect.top;
        mouse.active = true;
      }
    }

    resize();
    window.addEventListener("resize", resize);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseout", onLeave);
    window.addEventListener("click", onClick);
    window.addEventListener("touchmove", onTouch, { passive: true });
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseout", onLeave);
      window.removeEventListener("click", onClick);
      window.removeEventListener("touchmove", onTouch);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={`pointer-events-none absolute inset-0 h-full w-full ${className}`}
    />
  );
}
