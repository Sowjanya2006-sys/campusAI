import { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { Droplets, Menu, X, Sparkles } from "lucide-react";

const links = [
  { to: "/", label: "Home" },
  { to: "/assistant", label: "AI Assistant" },
  { to: "/study", label: "Study" },
  { to: "/documents", label: "Documents" },
  { to: "/placements", label: "Placements" },
  { to: "/events", label: "Events" },
  { to: "/dashboard", label: "Dashboard" },
  { to: "/about", label: "About" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const loc = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [loc.pathname]);

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-5 sm:pt-4">
      <nav
        className={`mx-auto flex max-w-6xl items-center justify-between rounded-2xl px-4 py-3 transition-all duration-300 ${
          scrolled ? "glass-strong shadow-lg shadow-black/40" : "glass"
        }`}
      >
        <Link to="/" className="group flex items-center gap-2.5">
          <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-flow-500 to-cyan-400 shadow-lg shadow-flow-500/30">
            <Droplets className="h-5 w-5 text-[#04120b]" strokeWidth={2.4} />
          </div>
          <div className="leading-tight">
            <span className="block text-[15px] font-bold tracking-tight text-white">
              CampusAI
            </span>
            <span className="block text-[9px] font-medium uppercase tracking-widest text-flow-400">
              NVIDIA Architecture
            </span>
          </div>
        </Link>

        <div className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-flow-500/15 text-flow-400"
                    : "text-slate-300 hover:text-white"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <Link
            to="/assistant"
            className="hidden items-center gap-1.5 rounded-xl bg-gradient-to-r from-flow-500 to-cyan-400 px-4 py-2 text-sm font-semibold text-[#04120b] transition-transform hover:scale-105 sm:flex"
          >
            <Sparkles className="h-4 w-4" /> Launch AI
          </Link>
          <button
            onClick={() => setOpen((v) => !v)}
            className="rounded-lg p-2 text-white lg:hidden"
            aria-label="Menu"
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </nav>

      {open && (
        <div className="mx-auto mt-2 max-w-6xl rounded-2xl glass-strong p-3 lg:hidden">
          <div className="grid grid-cols-2 gap-1">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                className={({ isActive }) =>
                  `rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-flow-500/15 text-flow-400"
                      : "text-slate-300 hover:bg-white/5 hover:text-white"
                  }`
                }
              >
                {l.label}
              </NavLink>
            ))}
          </div>
          <Link
            to="/assistant"
            className="mt-2 flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-flow-500 to-cyan-400 px-4 py-2.5 text-sm font-semibold text-[#04120b]"
          >
            <Sparkles className="h-4 w-4" /> Launch AI
          </Link>
        </div>
      )}
    </header>
  );
}
