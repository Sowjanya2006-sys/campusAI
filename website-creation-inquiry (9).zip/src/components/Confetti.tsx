import { useEffect, useState } from "react";

/**
 * Lightweight emoji + particle confetti burst.
 * Render it (keyed by a trigger value) to fire a one-shot celebration.
 */
const pieces = ["💧", "✨", "🎉", "💚", "🌊", "⚡", "🫧", "⭐"];

export default function Confetti({ fire }: { fire: number }) {
  const [items, setItems] = useState<
    { id: number; left: number; delay: number; e: string; dur: number }[]
  >([]);

  useEffect(() => {
    if (fire === 0) return;
    const batch = Array.from({ length: 26 }).map((_, i) => ({
      id: fire * 100 + i,
      left: Math.random() * 100,
      delay: Math.random() * 0.3,
      dur: 1.4 + Math.random() * 1.2,
      e: pieces[Math.floor(Math.random() * pieces.length)],
    }));
    setItems(batch);
    const t = setTimeout(() => setItems([]), 3000);
    return () => clearTimeout(t);
  }, [fire]);

  if (items.length === 0) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[55] overflow-hidden">
      {items.map((it) => (
        <span
          key={it.id}
          className="absolute top-[-40px] select-none text-xl"
          style={{
            left: `${it.left}%`,
            animation: `confettiFall ${it.dur}s ${it.delay}s ease-in forwards`,
          }}
        >
          {it.e}
        </span>
      ))}
    </div>
  );
}
