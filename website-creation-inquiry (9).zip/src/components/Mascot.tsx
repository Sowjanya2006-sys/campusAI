import { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";

/**
 * Aqua 💧 — the CampusAI mascot.
 * A bouncy water-droplet buddy that:
 *  - floats in the corner and blinks
 *  - drops fun tips / jokes in a speech bubble
 *  - bursts a shower of emojis when you click / pet it
 *  - reacts to the page you're on
 */

const tips: Record<string, string[]> = {
  "/": [
    "Pssst… click anywhere to make ripples! 💧",
    "Tap me for a little surprise! ✨",
    "Knowledge flows best downhill. Let's go! 🌊",
  ],
  "/assistant": [
    "Ask me anything — I don't get tired! 🤖",
    "Try a suggestion chip to get started ⚡",
    "I read the whole demo library so you don't have to 📚",
  ],
  "/study": [
    "Quiz yourself — future-you says thanks! 🎓",
    "Beginner today, wizard tomorrow 🧙",
  ],
  "/placements": [
    "Every wrong answer is a saved mistake in the interview 💼",
    "Streaks feel good. Go get 'em! 🔥",
  ],
  "/documents": ["Click 'Ask AI' on any doc — I'll summarize it! 📄"],
  "/events": ["Free snacks at demo events? …probably. 🍕"],
  "/dashboard": ["Look at those stats climb! 📈"],
  "/about": ["I'm powered by an architecture, not magic. Okay, a little magic. 🪄"],
};

const emojis = ["💧", "✨", "🌊", "💚", "⚡", "🎉", "🫧", "🐟"];

export default function Mascot() {
  const loc = useLocation();
  const [bubble, setBubble] = useState<string | null>(null);
  const [open, setOpen] = useState(true);
  const [wiggle, setWiggle] = useState(false);
  const [bursts, setBursts] = useState<{ id: number; x: number; y: number; e: string }[]>([]);
  const btnRef = useRef<HTMLButtonElement>(null);
  const idRef = useRef(0);

  // pick a contextual tip whenever the route changes
  useEffect(() => {
    const list = tips[loc.pathname] ?? tips["/"];
    const pick = list[Math.floor(Math.random() * list.length)];
    setBubble(pick);
    const t = setTimeout(() => setBubble(null), 5000);
    return () => clearTimeout(t);
  }, [loc.pathname]);

  // occasionally say something fun
  useEffect(() => {
    const iv = setInterval(() => {
      if (Math.random() > 0.55) {
        const list = tips[loc.pathname] ?? tips["/"];
        setBubble(list[Math.floor(Math.random() * list.length)]);
        setTimeout(() => setBubble(null), 4500);
      }
    }, 15000);
    return () => clearInterval(iv);
  }, [loc.pathname]);

  function pet() {
    setWiggle(true);
    setTimeout(() => setWiggle(false), 600);
    // emoji shower
    const rect = btnRef.current?.getBoundingClientRect();
    const cx = rect ? rect.left + rect.width / 2 : window.innerWidth - 60;
    const cy = rect ? rect.top : window.innerHeight - 80;
    const newBursts = Array.from({ length: 8 }).map(() => ({
      id: idRef.current++,
      x: cx + (Math.random() - 0.5) * 40,
      y: cy + (Math.random() - 0.5) * 20,
      e: emojis[Math.floor(Math.random() * emojis.length)],
    }));
    setBursts((b) => [...b, ...newBursts]);
    setTimeout(() => {
      setBursts((b) => b.filter((x) => !newBursts.some((n) => n.id === x.id)));
    }, 1100);

    const funny = [
      "Hehe, that tickles! 🫧",
      "Splish splash! 💦",
      "You found the secret pet button 🎉",
      "10/10 would flow again 🌊",
      "Bloop! 🐟",
    ];
    setBubble(funny[Math.floor(Math.random() * funny.length)]);
    setTimeout(() => setBubble(null), 2500);
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-4 right-4 z-40 flex h-10 w-10 items-center justify-center rounded-full glass-strong text-lg"
        aria-label="Show Aqua"
      >
        💧
      </button>
    );
  }

  return (
    <>
      {/* emoji bursts */}
      {bursts.map((b) => (
        <span
          key={b.id}
          className="pointer-events-none fixed z-[60] select-none text-xl"
          style={{
            left: b.x,
            top: b.y,
            ["--bx" as string]: `${(Math.random() - 0.5) * 120}px`,
            animation: "mascotBurst 1s ease-out forwards",
          }}
        >
          {b.e}
        </span>
      ))}

      <div className="fixed bottom-5 right-4 z-40 flex flex-col items-end gap-2 sm:right-6">
        {bubble && (
          <div className="max-w-[220px] rounded-2xl rounded-br-sm glass-strong px-3.5 py-2.5 text-xs font-medium text-slate-100 shadow-lg shadow-black/40">
            <button
              onClick={() => setOpen(false)}
              className="float-right ml-2 -mt-1 text-slate-500 hover:text-white"
              aria-label="Hide"
            >
              ×
            </button>
            {bubble}
          </div>
        )}
        <button
          ref={btnRef}
          onClick={pet}
          className="group relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-flow-500 to-cyan-400 text-3xl shadow-xl shadow-flow-500/40 transition-transform hover:scale-110 active:scale-95"
          style={{ animation: wiggle ? "mascotWiggle 0.6s ease" : "mascotFloat 4s ease-in-out infinite" }}
          aria-label="Pet Aqua the mascot"
        >
          <span className="drop-shadow">💧</span>
          <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-white/90 text-[9px]">
            👀
          </span>
        </button>
      </div>
    </>
  );
}
