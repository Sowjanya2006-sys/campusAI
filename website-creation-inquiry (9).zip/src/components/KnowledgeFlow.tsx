import { HelpCircle, Database, Cpu, Zap, MessageSquareText } from "lucide-react";

const stages = [
  { icon: HelpCircle, label: "Student Question", desc: "You ask anything", color: "#4ade80" },
  { icon: Database, label: "Knowledge Retrieval", desc: "Search the knowledge base", color: "#34d399" },
  { icon: Cpu, label: "AI Processing", desc: "Context is assembled (RAG)", color: "#22d3ee" },
  { icon: Zap, label: "NVIDIA AI Layer", desc: "Inference generates the answer", color: "#76b900" },
  { icon: MessageSquareText, label: "Answer", desc: "Grounded response + sources", color: "#4ade80" },
];

/** The signature knowledge-flow "waterfall" pipeline visualization. */
export default function KnowledgeFlow() {
  return (
    <div className="relative">
      {/* desktop: horizontal flow */}
      <div className="hidden items-stretch justify-between gap-2 md:flex">
        {stages.map((s, i) => (
          <div key={s.label} className="flex flex-1 items-center">
            <div className="reveal flex-1 rounded-2xl glass p-5 text-center" data-delay={i * 120}>
              <div
                className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl animate-float"
                style={{
                  background: `linear-gradient(135deg, ${s.color}33, ${s.color}11)`,
                  border: `1px solid ${s.color}55`,
                  animationDelay: `${i * 0.4}s`,
                }}
              >
                <s.icon className="h-6 w-6" style={{ color: s.color }} />
              </div>
              <h4 className="mt-3 text-sm font-semibold text-white">{s.label}</h4>
              <p className="mt-1 text-xs text-slate-400">{s.desc}</p>
            </div>
            {i < stages.length - 1 && (
              <svg className="h-8 w-10 shrink-0" viewBox="0 0 40 32" fill="none">
                <path
                  d="M2 16 H38"
                  stroke="#4ade80"
                  strokeWidth="2"
                  className="flow-line"
                />
                <path d="M32 10 L38 16 L32 22" stroke="#4ade80" strokeWidth="2" fill="none" />
              </svg>
            )}
          </div>
        ))}
      </div>

      {/* mobile: vertical waterfall */}
      <div className="flex flex-col items-center gap-0 md:hidden">
        {stages.map((s, i) => (
          <div key={s.label} className="flex w-full flex-col items-center">
            <div className="reveal w-full rounded-2xl glass p-4" data-delay={i * 100}>
              <div className="flex items-center gap-3">
                <div
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
                  style={{
                    background: `linear-gradient(135deg, ${s.color}33, ${s.color}11)`,
                    border: `1px solid ${s.color}55`,
                  }}
                >
                  <s.icon className="h-5 w-5" style={{ color: s.color }} />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">{s.label}</h4>
                  <p className="text-xs text-slate-400">{s.desc}</p>
                </div>
              </div>
            </div>
            {i < stages.length - 1 && (
              <svg className="h-8 w-6" viewBox="0 0 24 32" fill="none">
                <path d="M12 2 V30" stroke="#4ade80" strokeWidth="2" className="flow-line" />
                <path d="M6 24 L12 30 L18 24" stroke="#4ade80" strokeWidth="2" fill="none" />
              </svg>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
