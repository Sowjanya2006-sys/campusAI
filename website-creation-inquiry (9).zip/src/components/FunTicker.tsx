const facts = [
  "🌊 CampusAI answers flow from a Demo Knowledge Base — no waiting!",
  "🐍 Python is named after Monty Python, not the snake!",
  "🤖 Machine Learning models love GPUs like fish love water.",
  "💡 RAG = Retrieval Augmented Generation. Answers with receipts!",
  "☕ Java was almost called 'Oak'. Coffee won.",
  "🗄️ ACID keeps your database transactions squeaky clean.",
  "⚡ Binary search: O(log n) and proud of it.",
  "🎓 Every quiz you take waters your future brain-garden.",
];

export default function FunTicker() {
  const row = [...facts, ...facts];
  return (
    <div className="relative overflow-hidden border-y border-flow-500/10 bg-flow-500/[0.03] py-3 [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]">
      <div className="flex w-max gap-10" style={{ animation: "tickerScroll 40s linear infinite" }}>
        {row.map((f, i) => (
          <span key={i} className="whitespace-nowrap text-sm font-medium text-slate-300">
            {f}
            <span className="ml-10 text-flow-500/40">•</span>
          </span>
        ))}
      </div>
    </div>
  );
}
