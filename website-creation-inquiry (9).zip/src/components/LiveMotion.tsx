const clips = [
  {
    title: "Knowledge Streams",
    label: "Data in motion",
    src: "https://videos.pexels.com/video-files/29306492/12637575_1920_1080_30fps.mp4",
    emoji: "🌊",
  },
  {
    title: "Neural Flow",
    label: "AI processing",
    src: "https://videos.pexels.com/video-files/32522782/13868829_1920_1080_30fps.mp4",
    emoji: "🤖",
  },
  {
    title: "The Waterfall",
    label: "Let it flow",
    src: "https://videos.pexels.com/video-files/4140553/4140553-hd_1920_1080_30fps.mp4",
    emoji: "💧",
  },
];

/** Fun looping video cards — knowledge visualized in motion. */
export default function LiveMotion() {
  return (
    <div className="grid gap-5 md:grid-cols-3">
      {clips.map((c, i) => (
        <div
          key={c.title}
          className="reveal group relative overflow-hidden rounded-2xl border border-flow-500/15 bg-black"
          data-delay={i * 90}
        >
          <video
            className="h-56 w-full object-cover opacity-80 transition-all duration-500 group-hover:scale-105 group-hover:opacity-100"
            src={c.src}
            autoPlay
            loop
            muted
            playsInline
            preload="metadata"
          />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#04070a] via-[#04070a]/40 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <span className="text-2xl">{c.emoji}</span>
            <h4 className="mt-1 text-base font-semibold text-white">{c.title}</h4>
            <p className="text-xs text-flow-400">{c.label}</p>
          </div>
          <div className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-black/50 px-2 py-0.5 text-[10px] font-medium text-white backdrop-blur">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-400" /> LIVE
          </div>
        </div>
      ))}
    </div>
  );
}
