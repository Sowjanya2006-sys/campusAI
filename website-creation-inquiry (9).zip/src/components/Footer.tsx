import { Droplets } from "lucide-react";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="relative mt-24 border-t border-flow-500/10 px-6 py-14">
      <div className="mx-auto max-w-5xl text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-flow-500 to-cyan-400 shadow-lg shadow-flow-500/30">
          <Droplets className="h-7 w-7 text-[#04120b]" strokeWidth={2.4} />
        </div>
        <h3 className="mt-5 text-3xl font-bold tracking-tight text-white">CampusAI</h3>
        <p className="mt-2 text-lg font-medium text-flow-400">Let Knowledge Flow.</p>
        <p className="mx-auto mt-4 max-w-lg text-sm text-slate-400">
          An intelligent campus assistant designed to connect students with knowledge through AI.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-slate-400">
          <Link to="/assistant" className="hover:text-white">AI Assistant</Link>
          <Link to="/study" className="hover:text-white">Study Lab</Link>
          <Link to="/placements" className="hover:text-white">Placements</Link>
          <Link to="/documents" className="hover:text-white">Documents</Link>
          <Link to="/about" className="hover:text-white">About</Link>
        </div>

        <div className="mt-8 inline-flex items-center gap-2 rounded-full border border-flow-500/20 bg-flow-500/5 px-4 py-1.5 text-xs font-medium text-slate-300">
          <span className="h-2 w-2 rounded-full bg-flow-400" />
          Demo Project • NVIDIA AI Architecture
        </div>
        <p className="mt-6 text-xs text-slate-600">
          For educational demonstration only. Not affiliated with, sponsored, or endorsed by NVIDIA.
          All college data shown is fictional demo content.
        </p>
      </div>
    </footer>
  );
}
